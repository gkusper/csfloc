package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

public final class CSFLOC_2WL4 {
    public static void main(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("--help")) {
            printUsage();
            return;
        }
        Options options = new Options();
        int i = 1;
        if (i < args.length && !args[i].startsWith("--")) options.strategy = args[i++];
        for (; i < args.length; i++) {
            String option = args[i];
            if (i + 1 >= args.length) throw new IllegalArgumentException("Missing value for " + option);
            String value = args[++i];
            switch (option) {
                case "--cache":
                    if (!value.equals("off") && !value.equals("g-old")) throw new IllegalArgumentException("Cache must be off or g-old");
                    options.cache = value.equals("g-old");
                    break;
                case "--strategy": options.strategy = value; break;
                case "--clustering": options.clusteringFactor = Integer.parseInt(value); break;
                case "--limit-ms": options.limitMs = Long.parseLong(value); break;
                default: throw new IllegalArgumentException("Unknown option: " + option);
            }
        }
        if (options.limitMs < 1 || options.limitMs > 86400000L) throw new IllegalArgumentException("Limit must be 1..86400000 milliseconds");
        Formula formula = new HighLevelReader(DimacsParser.parseRaw(Path.of(args[0])), options.strategy, options.clusteringFactor).getFormula();
        CSFLOCSolver solver = new CSFLOCSolver(formula, options.cache, options.limitMs);
        Result result;
        try {
            result = solver.solve();
        } catch (RunLimit limit) {
            System.out.println("s UNKNOWN");
            solver.stats.print();
            return;
        }
        if (result.sat && !SimpleResultChecker.checkInternal(formula, result.internalModel)) throw new AssertionError("Invalid SAT model");
        result.print();
    }

    private static void printUsage() {
        System.out.println("CSFLOC_2WL4: Two-Watched-Literals, fourth major version");
        System.out.println("Usage: java -cp build org.example.CSFLOC_2WL4 <input.cnf> [strategy] [options]");
        System.out.println("  --cache off|g-old     Default: off (original O0)");
        System.out.println("  --strategy <name>    Default: NON; B,C,H,I,R,S,W,T,U can be combined");
        System.out.println("  --clustering <int>   Default: 5; effective minimum: 2");
        System.out.println("  --limit-ms <int>     Cooperative limit: 1..86400000, default 86400000");
    }

    static final class Options {
        boolean cache = false;
        String strategy = "NON";
        int clusteringFactor = 5;
        long limitMs = Long.getLong("csfloc.limitMs", 86400000L);
    }

    static final class RunLimit extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    static class ExactCache {
        final Clause[][] pos,neg;
        ExactCache(int n){pos=new Clause[n+1][10];neg=new Clause[n+1][10];}
        void add(Clause c){

            if(c==null||c.lits.length==0||c.lits.length==c.lastVar)return;
            Clause[] cache=c.lastLiteral>0?pos[c.lastVar]:neg[c.lastVar];
            if(c.lits.length<=5||cache[2]==null){cache[2]=cache[1];cache[1]=cache[0];cache[0]=c;}
            else if(c.lits.length<=9||cache[5]==null){cache[5]=cache[4];cache[4]=cache[3];cache[3]=c;}
            else{cache[9]=cache[8];cache[8]=cache[7];cache[7]=cache[6];cache[6]=c;}

        }
        Clause find(boolean[] counter,int index){

            if(index>0){Clause[] bucket=pos[index];for(int i=0;i<bucket.length;i++){Clause c=bucket[i];if(c==null)break;if(c.subsumedBy(counter))return c;}}
            for(index++;index<neg.length;index++){Clause[] bucket=neg[index];for(int i=0;i<bucket.length;i++){Clause c=bucket[i];if(c==null)break;if(c.subsumedBy(counter))return c;}}
            return null;
        }

    }

    static final class Clause {
        final int id;
        final int[] vars; final boolean[] isPos;
        boolean subsumedBy(boolean[] counter){for(int i=0;i<lits.length-1;i++)if(counter[vars[i]]!=isPos[i])return false;return true;}
        final int[] lits;
        final int[] pos;
        final int[] neg;
        final int lastVar;
        final int lastLiteral;
        final boolean lastSignPositive;

        Clause(int id, int[] lits) {
            this.id = id;
            this.lits = Arrays.copyOf(lits,lits.length);
            {vars=new int[lits.length];isPos=new boolean[lits.length];for(int i=0;i<lits.length;i++){vars[i]=Math.abs(lits[i]);isPos[i]=lits[i]>0;}}

            int pc = 0, nc = 0;
            for (int lit : lits) {
                if (lit > 0) pc++; else nc++;
            }
            this.pos = new int[pc];
            this.neg = new int[nc];
            int pi = 0, ni = 0;
            for (int lit : lits) {
                if (lit > 0) pos[pi++] = lit;
                else neg[ni++] = -lit;
            }
            Arrays.sort(pos);
            Arrays.sort(neg);

            if (lits.length == 0) {
                this.lastVar = 0;
                this.lastLiteral = 0;
                this.lastSignPositive = false;
            } else {
                this.lastLiteral = lits[lits.length - 1];
                this.lastVar = Math.abs(lastLiteral);
                this.lastSignPositive = lastLiteral > 0;
            }
        }

    }

    static final class RawFormula {
        final int variables;
        final int declaredClauses;
        final ArrayList<int[]> clauses;
        final boolean hasEmptyClause;
        final long parsedClauses;
        final long malformedTrailingClauses;

        RawFormula(int variables, int declaredClauses, ArrayList<int[]> clauses,
                   boolean hasEmptyClause, long parsedClauses, long malformedTrailingClauses) {
            this.variables = variables;
            this.declaredClauses = declaredClauses;
            this.clauses = clauses;
            this.hasEmptyClause = hasEmptyClause;
            this.parsedClauses = parsedClauses;
            this.malformedTrailingClauses = malformedTrailingClauses;
        }
    }

    static final class Formula {
        final int variables;
        final int declaredClauses;
        final Clause[] clauses;
        final boolean hasEmptyClause;
        final long parsedClauses;
        final long tautologicalClausesSkipped;
        final long duplicateLiteralsSkipped;
        final long malformedTrailingClauses;
        final int[] translate;
        final int[] reverseTranslate;
        final String renamingStrategy;
        final int clusteringFactor;

        Formula(int variables,
                int declaredClauses,
                Clause[] clauses,
                boolean hasEmptyClause,
                long parsedClauses,
                long tautologicalClausesSkipped,
                long duplicateLiteralsSkipped,
                long malformedTrailingClauses,
                int[] translate,
                int[] reverseTranslate,
                String renamingStrategy,
                int clusteringFactor) {
            this.variables = variables;
            this.declaredClauses = declaredClauses;
            this.clauses = clauses;
            this.hasEmptyClause = hasEmptyClause;
            this.parsedClauses = parsedClauses;
            this.tautologicalClausesSkipped = tautologicalClausesSkipped;
            this.duplicateLiteralsSkipped = duplicateLiteralsSkipped;
            this.malformedTrailingClauses = malformedTrailingClauses;
            this.translate = translate;
            this.reverseTranslate = reverseTranslate;
            this.renamingStrategy = renamingStrategy;
            this.clusteringFactor = clusteringFactor;
        }
    }

    static final class DimacsParser {
        static RawFormula parseRaw(Path file) throws IOException {
            int n = -1;
            int declaredClauses = -1;
            ArrayList<int[]> clauses = new ArrayList<>();
            ArrayList<Integer> rawClause = new ArrayList<>();
            boolean hasEmptyClause = false;
            long parsedClauses = 0;
            long malformedTrailingClauses = 0;

            try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                String line;
                int lineNo = 0;
                while ((line = br.readLine()) != null) {
                    lineNo++;
                    String trimmed = line.trim();
                    if (trimmed.isEmpty() || trimmed.startsWith("c") || trimmed.startsWith("%")) continue;

                    if (trimmed.startsWith("p")) {
                        String[] parts = trimmed.split("\\s+");
                        if (parts.length < 4 || !parts[0].equals("p") || !parts[1].equalsIgnoreCase("cnf")) {
                            throw new IOException("Invalid DIMACS problem line at line " + lineNo + ": " + line);
                        }
                        n = Integer.parseInt(parts[2]);
                        declaredClauses = Integer.parseInt(parts[3]);
                        continue;
                    }

                    if (n < 0) throw new IOException("Clause data before problem line at line " + lineNo);

                    String[] parts = trimmed.split("\\s+");
                    for (String part : parts) {
                        if (part.isEmpty()) continue;
                        int lit;
                        try {
                            lit = Integer.parseInt(part);
                        } catch (NumberFormatException ex) {
                            throw new IOException("Invalid literal token at line " + lineNo + ": " + part);
                        }
                        if (lit == 0) {
                            int[] arr = toIntArray(rawClause);
                            if (arr.length == 0) hasEmptyClause = true;
                            clauses.add(arr);
                            parsedClauses++;
                            rawClause.clear();
                        } else {
                            int var = Math.abs(lit);
                            if (var < 1 || var > n) throw new IOException("Literal outside range at line " + lineNo + ": " + lit);
                            rawClause.add(lit);
                        }
                    }
                }
            }

            if (n < 0) throw new IOException("Missing DIMACS problem line.");
            if (!rawClause.isEmpty()) {
                int[] arr = toIntArray(rawClause);
                if (arr.length == 0) hasEmptyClause = true;
                clauses.add(arr);
                parsedClauses++;
                malformedTrailingClauses++;
            }

            return new RawFormula(n, declaredClauses, clauses, hasEmptyClause, parsedClauses, malformedTrailingClauses);
        }

        private static int[] toIntArray(ArrayList<Integer> list) {
            int[] arr = new int[list.size()];
            for (int i = 0; i < list.size(); i++) arr[i] = list.get(i);
            return arr;
        }
    }

    static final class HighLevelReader {
        final RawFormula raw;
        final int n;
        final String strategy;
        final int clusteringFactor;
        final ArrayList<int[]> workingClauses;
        int[] translate;

        HighLevelReader(RawFormula raw, String strategy, int clusteringFactor) {
            this.raw = raw;
            this.n = raw.variables;
            this.strategy = (strategy == null || strategy.equalsIgnoreCase("NON")) ? "" : strategy;
            this.clusteringFactor = Math.max(2, clusteringFactor);
            this.workingClauses = deepCopy(raw.clauses);
            this.translate = identity(n);
            applyStrategies();
        }

        Formula getFormula() {
            long tautologicalClausesSkipped = 0;
            long duplicateLiteralsSkipped = 0;

            ArrayList<Clause> out = new ArrayList<>();
            int[] marks = new int[n + 1];
            ArrayList<Integer> touched = new ArrayList<>();
            boolean hasEmpty = raw.hasEmptyClause;

            for (int[] rawClause : workingClauses) {
                NormalizeResult nr = normalizeTranslatedClause(rawClause, marks, touched, out.size());
                duplicateLiteralsSkipped += nr.duplicateLiterals;

                if (nr.emptyClause) {
                    hasEmpty = true;
                } else if (nr.tautologicalClause) {
                    tautologicalClausesSkipped++;
                } else {
                    out.add(nr.clause);
                }
            }

            int[] reverse = new int[n + 1];
            for (int original = 1; original <= n; original++) {
                reverse[translate[original]] = original;
            }

            return new Formula(
                    n,
                    raw.declaredClauses,
                    out.toArray(new Clause[0]),
                    hasEmpty,
                    raw.parsedClauses,
                    tautologicalClausesSkipped,
                    duplicateLiteralsSkipped,
                    raw.malformedTrailingClauses,
                    translate,
                    reverse,
                    strategy.isEmpty() ? "NON" : strategy,
                    clusteringFactor);
        }

        private void applyStrategies() {
            int[] oldTranslate = null;

            for (int i = 0; i < strategy.length(); i++) {
                char c = Character.toUpperCase(strategy.charAt(i));
                int[] tr = null;

                switch (c) {
                    case 'B': tr = renameBlackClauses(workingClauses); break;
                    case 'W': tr = renameWhiteClauses(workingClauses); break;
                    case 'H': tr = renameDefiniteHornClauses(workingClauses); break;
                    case 'I': tr = renameIslandClauses(workingClauses); break;
                    case 'S': tr = renameStraitClauses(workingClauses); break;
                    case 'R': tr = simplerVariableRenaming(createVariablePairs(workingClauses)); break;
                    case 'C': tr = clusterVariables(createVariablePairs(workingClauses), clusteringFactor); break;
                    case 'T': tr = renameTwoSatPrefixStrategy(workingClauses); break;
                    case 'U': tr = renameUnitFirstStrategy(workingClauses); break;
                    default: break;
                }

                if (tr != null) {
                    translateVariables(workingClauses, tr);
                    translate = productOfTranslates(tr, oldTranslate);
                    oldTranslate = translate;
                }
            }

            if (oldTranslate == null) {
                translate = identity(n);
            }
        }

        private static ArrayList<int[]> deepCopy(ArrayList<int[]> cs) {
            ArrayList<int[]> copy = new ArrayList<>(cs.size());
            for (int[] c : cs) {
                copy.add(Arrays.copyOf(c, c.length));
            }
            return copy;
        }

        private int[] identity(int n) {
            int[] id = new int[n + 1];
            for (int i = 0; i <= n; i++) {
                id[i] = i;
            }
            return id;
        }

        private void translateVariables(ArrayList<int[]> cs, int[] tr) {
            for (int[] clause : cs) {
                for (int i = 0; i < clause.length; i++) {
                    int lit = clause[i];
                    int var = tr[Math.abs(lit)];
                    clause[i] = lit > 0 ? var : -var;
                }
            }
        }

        private int[] productOfTranslates(int[] tr, int[] old) {
            if (old == null) return tr;

            int[] product = new int[tr.length];
            product[0] = 0;

            for (int i = 1; i < tr.length; i++) {
                product[i] = tr[old[i]];
            }

            return product;
        }

        private int[] renameBlackClauses(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            int next = 1;

            for (int[] clause : cs) {
                boolean allNeg = clause.length > 0;
                for (int lit : clause) {
                    if (lit > 0) {
                        allNeg = false;
                        break;
                    }
                }
                if (!allNeg) continue;

                for (int lit : clause) {
                    int v = Math.abs(lit);
                    if (tr[v] == 0) {
                        tr[v] = next++;
                    }
                    if (next > n) return fillRemaining(tr, next);
                }
            }

            return fillRemaining(tr, next);
        }

        private int[] renameWhiteClauses(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            int next = 1;

            for (int[] clause : cs) {
                boolean allPos = clause.length > 0;
                for (int lit : clause) {
                    if (lit < 0) {
                        allPos = false;
                        break;
                    }
                }
                if (!allPos) continue;

                for (int lit : clause) {
                    int v = Math.abs(lit);
                    if (tr[v] == 0) {
                        tr[v] = next++;
                    }
                    if (next > n) return fillRemaining(tr, next);
                }
            }

            return fillRemaining(tr, next);
        }

        private int[] renameDefiniteHornClauses(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            int next = 1;

            for (int[] clause : cs) {
                int posCount = 0;
                for (int lit : clause) {
                    if (lit > 0) posCount++;
                }
                if (posCount != 1) continue;

                int notRenamed = 0;
                for (int lit : clause) {
                    if (tr[Math.abs(lit)] == 0) notRenamed++;
                }
                if (notRenamed != clause.length) continue;

                for (int lit : clause) {
                    int v = Math.abs(lit);
                    if (tr[v] == 0) {
                        tr[v] = next++;
                    }
                    if (next > n) return fillRemaining(tr, next);
                }
            }

            return fillRemaining(tr, next);
        }

        private int[] renameIslandClauses(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            int next = 1;

            for (int[] clause : cs) {
                int posCount = 0;
                int posIndex = -1;

                for (int i = 0; i < clause.length; i++) {
                    if (clause[i] > 0) {
                        posCount++;
                        posIndex = i;
                    }
                }

                if (posCount != 1) continue;

                for (int i = 0; i < clause.length; i++) {
                    if (i == posIndex) continue;

                    int v = Math.abs(clause[i]);
                    if (tr[v] == 0) {
                        tr[v] = next++;
                    }
                    if (next > n) return fillRemaining(tr, next);
                }

                int pv = Math.abs(clause[posIndex]);
                if (tr[pv] == 0) {
                    tr[pv] = next++;
                }
                if (next > n) return fillRemaining(tr, next);
            }

            return fillRemaining(tr, next);
        }

        private int[] renameStraitClauses(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            int next = 1;

            for (int[] clause : cs) {
                int negCount = 0;
                int negIndex = -1;

                for (int i = 0; i < clause.length; i++) {
                    if (clause[i] < 0) {
                        negCount++;
                        negIndex = i;
                    }
                }

                if (negCount != 1) continue;

                int nv = Math.abs(clause[negIndex]);
                if (tr[nv] == 0) {
                    tr[nv] = next++;
                }
                if (next > n) return fillRemaining(tr, next);

                for (int i = 0; i < clause.length; i++) {
                    if (i == negIndex) continue;

                    int v = Math.abs(clause[i]);
                    if (tr[v] == 0) {
                        tr[v] = next++;
                    }
                    if (next > n) return fillRemaining(tr, next);
                }
            }

            return fillRemaining(tr, next);
        }

        /**
         * Exact T with incremental incidence counters and an indexed max heap.
         * Selection is unchanged: positive score, non-waiting first, then larger
         * active-clause score, larger static frequency, smaller variable index.
         * A clause leaves the score on its unique 3 -> 2 transition. Waiting is
         * monotone for an unselected variable, so heap keys only decrease.
         * With L occurrences and q initially long clauses: O(L+n+m+(n+q)log(n+1))
         * time and O(L+n+m) memory. This preserves the old T permutation exactly;
         * prefix quality remains heuristic (neither minimum nor maximum binary).
         */
        private int[] renameTwoSatPrefixStrategy(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            if (n == 0) return tr;
            int[][] clauseVars = createDistinctClauseVars(cs);
            int[] remaining = new int[clauseVars.length];
            int[] frequency = new int[n + 1];
            int[] score = new int[n + 1];
            boolean[] waiting = new boolean[n + 1];
            int active = 0;
            for (int i = 0; i < clauseVars.length; i++) {
                remaining[i] = clauseVars[i].length;
                if (remaining[i] > 2) active++;
                for (int v : clauseVars[i]) {
                    frequency[v]++;
                    if (remaining[i] > 2) score[v]++;
                }
            }
            if (active == 0) return fillRemaining(tr, 1);

            // Compact variable -> clause incidence index, as in U-lite.
            int[] start = new int[n + 2];
            for (int v = 1; v <= n; v++) start[v + 1] = start[v] + frequency[v];
            int[] incidence = new int[start[n + 1]];
            int[] cursor = Arrays.copyOf(start, start.length);
            for (int i = 0; i < clauseVars.length; i++)
                for (int v : clauseVars[i]) incidence[cursor[v]++] = i;

            TwoSatPrefixHeap heap = new TwoSatPrefixHeap(score, frequency, waiting);
            int next = 1;
            while (active > 0) {
                int v = heap.removeBest();
                if (score[v] <= 0) throw new IllegalStateException("T: no active variable");
                tr[v] = next++;
                for (int p = start[v]; p < start[v + 1]; p++) {
                    int i = incidence[p];
                    if (remaining[i]-- == 3) {
                        active--;
                        // Scan this clause once; exactly two unselected variables remain.
                        for (int u : clauseVars[i]) {
                            if (tr[u] == 0) {
                                score[u]--;
                                waiting[u] = true;
                                heap.decreased(u);
                            }
                        }
                    }
                }
            }
            return fillRemaining(tr, next);
        }

        private static final class TwoSatPrefixHeap {
            final int[] heap, position, score, frequency;
            final boolean[] waiting;
            int size;

            TwoSatPrefixHeap(int[] score, int[] frequency, boolean[] waiting) {
                this.score = score;
                this.frequency = frequency;
                this.waiting = waiting;
                heap = new int[score.length - 1];
                position = new int[score.length];
                Arrays.fill(position, -1);
                for (int v = 1; v < score.length; v++) {
                    if (score[v] > 0) {
                        position[v] = size;
                        heap[size++] = v;
                    }
                }
                for (int p = size / 2 - 1; p >= 0; p--) siftDown(p);
            }

            boolean better(int a, int b) {
                if ((score[a] > 0) != (score[b] > 0)) return score[a] > 0;
                if (waiting[a] != waiting[b]) return !waiting[a];
                if (score[a] != score[b]) return score[a] > score[b];
                if (frequency[a] != frequency[b]) return frequency[a] > frequency[b];
                return a < b;
            }

            int removeBest() {
                if (size == 0) throw new IllegalStateException("T: empty heap");
                int v = heap[0];
                position[v] = -1;
                if (--size > 0) {
                    heap[0] = heap[size];
                    position[heap[0]] = 0;
                    siftDown(0);
                }
                return v;
            }

            void decreased(int v) { siftDown(position[v]); }

            void siftDown(int p) {
                int v = heap[p];
                while (p < size / 2) {
                    int child = 2 * p + 1;
                    if (child + 1 < size && better(heap[child + 1], heap[child])) child++;
                    if (!better(heap[child], v)) break;
                    heap[p] = heap[child];
                    position[heap[p]] = p;
                    p = child;
                }
                heap[p] = v;
                position[v] = p;
            }
        }

        private int[] renameUnitFirstStrategy(ArrayList<int[]> cs) {
            int[] tr = new int[n + 1];
            if (n == 0) return tr;

            UnitLiteData data = buildUnitLiteData(cs);
            int[] order = unitLiteFrequencyOrder(data.frequency);
            boolean[] selected = new boolean[n + 1];
            int[] deferred = new int[n];
            int deferredCount = 0;
            int next = 1;

            for (int v : order) {
                if (data.waitingCount[v] > 0) {
                    deferred[deferredCount++] = v;
                } else {
                    next = assignUnitLiteVariable(v, tr, selected, data, next);
                }
            }

            for (int i = 0; i < deferredCount; i++) {
                int v = deferred[i];
                tr[v] = next++;
            }

            return tr;
        }

        private UnitLiteData buildUnitLiteData(ArrayList<int[]> cs) {
            int clauseCount = cs.size();
            int[] remaining = new int[clauseCount];
            int[] frequency = new int[n + 1];
            int[] waitingCount = new int[n + 1];
            int[] seen = new int[n + 1];
            int stamp = 1;

            for (int clauseIndex = 0; clauseIndex < clauseCount; clauseIndex++) {
                if (stamp == Integer.MAX_VALUE) {
                    Arrays.fill(seen, 0);
                    stamp = 1;
                }

                int distinct = 0;
                int soleVariable = 0;

                for (int lit : cs.get(clauseIndex)) {
                    int v = Math.abs(lit);
                    if (v < 1 || v > n || seen[v] == stamp) continue;

                    seen[v] = stamp;
                    distinct++;
                    soleVariable = v;
                    frequency[v]++;
                }

                remaining[clauseIndex] = distinct;
                if (distinct == 1) {
                    waitingCount[soleVariable]++;
                }
                stamp++;
            }

            int[] occurrenceStart = new int[n + 2];
            for (int v = 1; v <= n; v++) {
                occurrenceStart[v + 1] = occurrenceStart[v] + frequency[v];
            }

            int[] clauseIndices = new int[occurrenceStart[n + 1]];
            int[] cursor = Arrays.copyOf(occurrenceStart, occurrenceStart.length);

            Arrays.fill(seen, 0);
            stamp = 1;

            for (int clauseIndex = 0; clauseIndex < clauseCount; clauseIndex++) {
                if (stamp == Integer.MAX_VALUE) {
                    Arrays.fill(seen, 0);
                    stamp = 1;
                }

                for (int lit : cs.get(clauseIndex)) {
                    int v = Math.abs(lit);
                    if (v < 1 || v > n || seen[v] == stamp) continue;

                    seen[v] = stamp;
                    clauseIndices[cursor[v]++] = clauseIndex;
                }
                stamp++;
            }

            return new UnitLiteData(
                    cs,
                    remaining,
                    frequency,
                    waitingCount,
                    occurrenceStart,
                    clauseIndices);
        }

        private int[] unitLiteFrequencyOrder(int[] frequency) {
            int maxFrequency = 0;
            for (int v = 1; v <= n; v++) {
                if (frequency[v] > maxFrequency) {
                    maxFrequency = frequency[v];
                }
            }

            int[] bucketSize = new int[maxFrequency + 1];
            for (int v = 1; v <= n; v++) {
                bucketSize[frequency[v]]++;
            }

            int[] bucketStart = new int[maxFrequency + 1];
            int position = 0;
            for (int f = maxFrequency; f >= 0; f--) {
                bucketStart[f] = position;
                position += bucketSize[f];
            }

            int[] cursor = Arrays.copyOf(bucketStart, bucketStart.length);
            int[] order = new int[n];

            for (int v = 1; v <= n; v++) {
                order[cursor[frequency[v]]++] = v;
            }

            return order;
        }

        private int assignUnitLiteVariable(int v,
                                           int[] tr,
                                           boolean[] selected,
                                           UnitLiteData data,
                                           int next) {
            selected[v] = true;
            tr[v] = next++;

            for (int p = data.occurrenceStart[v];
                 p < data.occurrenceStart[v + 1];
                 p++) {

                int clauseIndex = data.clauseIndices[p];
                int before = data.remaining[clauseIndex];
                if (before <= 0) continue;

                data.remaining[clauseIndex] = before - 1;

                if (before == 2) {
                    int last = firstUnselectedUnitLiteVariable(
                            data.clauses.get(clauseIndex), selected);
                    if (last != 0) {
                        data.waitingCount[last]++;
                    }
                }
            }

            return next;
        }

        private int firstUnselectedUnitLiteVariable(int[] clause,
                                                    boolean[] selected) {
            for (int lit : clause) {
                int v = Math.abs(lit);
                if (v >= 1 && v <= n && !selected[v]) {
                    return v;
                }
            }
            return 0;
        }

        private static final class UnitLiteData {
            final ArrayList<int[]> clauses;
            final int[] remaining;
            final int[] frequency;
            final int[] waitingCount;
            final int[] occurrenceStart;
            final int[] clauseIndices;

            UnitLiteData(ArrayList<int[]> clauses,
                         int[] remaining,
                         int[] frequency,
                         int[] waitingCount,
                         int[] occurrenceStart,
                         int[] clauseIndices) {
                this.clauses = clauses;
                this.remaining = remaining;
                this.frequency = frequency;
                this.waitingCount = waitingCount;
                this.occurrenceStart = occurrenceStart;
                this.clauseIndices = clauseIndices;
            }
        }

        private int[] fillRemaining(int[] tr, int next) {
            for (int v = 1; v <= n; v++) {
                if (tr[v] == 0) {
                    tr[v] = next++;
                }
            }
            return tr;
        }

        private int[][] createDistinctClauseVars(ArrayList<int[]> cs) {
            int[][] out = new int[cs.size()][];
            int[] seen = new int[n + 1];
            int stamp = 1;

            for (int i = 0; i < cs.size(); i++) {
                int[] clause = cs.get(i);
                int[] tmp = new int[clause.length];
                int count = 0;

                if (stamp == Integer.MAX_VALUE) {
                    Arrays.fill(seen, 0);
                    stamp = 1;
                }

                for (int lit : clause) {
                    int v = Math.abs(lit);
                    if (v < 1 || v > n) continue;

                    if (seen[v] != stamp) {
                        seen[v] = stamp;
                        tmp[count++] = v;
                    }
                }

                out[i] = Arrays.copyOf(tmp, count);
                stamp++;
            }

            return out;
        }

        private int[] variableFrequency(int[][] clauseVars) {
            int[] frequency = new int[n + 1];

            for (int[] vars : clauseVars) {
                for (int v : vars) {
                    frequency[v]++;
                }
            }

            return frequency;
        }

        private boolean hasClauseWithMoreThanTwoRemaining(int[] remaining) {
            for (int r : remaining) {
                if (r > 2) return true;
            }
            return false;
        }

        private void recomputeTwoSatWaiting(int[][] clauseVars,
                                            int[] remaining,
                                            boolean[] selected,
                                            boolean[] waiting) {
            Arrays.fill(waiting, false);

            for (int i = 0; i < clauseVars.length; i++) {
                if (clauseVars[i].length <= 2) continue;

                if (remaining[i] > 0 && remaining[i] <= 2) {
                    for (int v : clauseVars[i]) {
                        if (!selected[v]) {
                            waiting[v] = true;
                        }
                    }
                }
            }
        }

        private int bestTwoSatPrefixVariable(int[][] clauseVars,
                                             int[] remaining,
                                             boolean[] selected,
                                             boolean[] waiting,
                                             int[] frequency,
                                             boolean allowWaiting) {
            int bestVar = 0;
            int bestScore = 0;
            int bestFrequency = -1;

            for (int v = 1; v <= n; v++) {
                if (selected[v]) continue;
                if (!allowWaiting && waiting[v]) continue;

                int score = 0;

                for (int i = 0; i < clauseVars.length; i++) {
                    if (remaining[i] <= 2) continue;

                    if (containsVar(clauseVars[i], v)) {
                        score++;
                    }
                }

                if (score > bestScore
                        || (score == bestScore && score > 0 && frequency[v] > bestFrequency)
                        || (score == bestScore && score > 0 && frequency[v] == bestFrequency && (bestVar == 0 || v < bestVar))) {
                    bestVar = v;
                    bestScore = score;
                    bestFrequency = frequency[v];
                }
            }

            return bestVar;
        }

        private int assignVariable(int v,
                                   int[] tr,
                                   boolean[] selected,
                                   int[][] clauseVars,
                                   int[] remaining,
                                   int next) {
            if (v < 1 || v > n || selected[v] || next > n) {
                return next;
            }

            selected[v] = true;
            tr[v] = next++;

            for (int i = 0; i < clauseVars.length; i++) {
                if (remaining[i] > 0 && containsVar(clauseVars[i], v)) {
                    remaining[i]--;
                }
            }

            return next;
        }

        private boolean containsVar(int[] vars, int v) {
            for (int x : vars) {
                if (x == v) return true;
            }
            return false;
        }

        private int[] createVariablePairs(ArrayList<int[]> cs) {
            HashMap<Int2, Integer> counts = new HashMap<>();
            int best = 1;

            for (int[] source : cs) {
                if (source.length < 2 || source.length > 12) continue;

                for (int i = 0; i < source.length - 1; i++) {
                    int a = Math.abs(source[i]);

                    for (int j = i + 1; j < source.length; j++) {
                        int b = Math.abs(source[j]);
                        if (a == b) continue;

                        Int2 key = new Int2(a, b);
                        int c = counts.getOrDefault(key, 0) + 1;
                        counts.put(key, c);

                        if (c > best) {
                            best = c;
                        }
                    }
                }
            }

            int[] bucketSizes = new int[best + 1];

            for (int c : counts.values()) {
                bucketSizes[best - c]++;
            }

            int[] indices = new int[best + 1];

            for (int i = 1; i < indices.length; i++) {
                indices[i] = indices[i - 1] + bucketSizes[i - 1] * 2;
            }

            int[] pairs = new int[counts.size() * 2];

            for (Map.Entry<Int2, Integer> e : counts.entrySet()) {
                int idx = indices[best - e.getValue()];
                pairs[idx] = e.getKey().a;
                pairs[idx + 1] = e.getKey().b;
                indices[best - e.getValue()] += 2;
            }

            return pairs;
        }

        private int[] simplerVariableRenaming(int[] pairs) {
            int[] tr = new int[n + 1];
            int next = 1;

            for (int v : pairs) {
                if (tr[v] == 0) {
                    tr[v] = next++;
                }

                if (next > n) break;
            }

            return fillRemaining(tr, next);
        }

        private int[] clusterVariables(int[] pairs, int clusterLimit) {
            int[] alloc = new int[n + 1];
            int[] size = new int[n + 1];
            ArrayList<int[]> clusters = new ArrayList<>();
            clusters.add(new int[clusterLimit]);
            int count = 0;

            for (int i = 0; i + 1 < pairs.length; i += 2) {
                int a = pairs[i];
                int b = pairs[i + 1];

                if (a == 0 || b == 0) continue;

                int ca = alloc[a];
                int cb = alloc[b];

                if (ca == 0 && cb == 0) {
                    count++;
                    int[] cl = new int[clusterLimit];
                    cl[0] = a;
                    cl[1] = b;
                    clusters.add(cl);
                    alloc[a] = count;
                    alloc[b] = count;
                    size[count] = 2;
                } else if (ca == 0) {
                    if (size[cb] < clusterLimit) {
                        alloc[a] = cb;
                        clusters.get(cb)[size[cb]++] = a;
                    } else {
                        count++;
                        int[] cl = new int[clusterLimit];
                        cl[0] = a;
                        clusters.add(cl);
                        alloc[a] = count;
                        size[count] = 1;
                    }
                } else if (cb == 0) {
                    if (size[ca] < clusterLimit) {
                        alloc[b] = ca;
                        clusters.get(ca)[size[ca]++] = b;
                    } else {
                        count++;
                        int[] cl = new int[clusterLimit];
                        cl[0] = b;
                        clusters.add(cl);
                        alloc[b] = count;
                        size[count] = 1;
                    }
                } else if (ca != cb && size[ca] + size[cb] <= clusterLimit) {
                    int[] cla = clusters.get(ca);
                    int[] clb = clusters.get(cb);

                    for (int k = 0; k < size[cb]; k++) {
                        int v = clb[k];
                        cla[size[ca]++] = v;
                        alloc[v] = ca;
                    }

                    size[cb] = 0;
                }
            }

            int[] tr = new int[n + 1];
            int next = 1;

            for (int c = 1; c <= count; c++) {
                int[] cl = clusters.get(c);

                for (int j = 0; j < size[c]; j++) {
                    tr[cl[j]] = next++;
                }
            }

            return fillRemaining(tr, next);
        }

        private NormalizeResult normalizeTranslatedClause(int[] rawClause,
                                                          int[] marks,
                                                          ArrayList<Integer> touched,
                                                          int id) {
            if (rawClause.length == 0) {
                return NormalizeResult.empty();
            }

            boolean taut = false;
            long dup = 0;

            for (int lit : rawClause) {
                int v = Math.abs(lit);
                int sign = lit > 0 ? 1 : -1;

                if (marks[v] == sign) {
                    dup++;
                } else if (marks[v] == -sign) {
                    taut = true;
                } else {
                    marks[v] = sign;
                    touched.add(v);
                }
            }

            if (taut) {
                for (int v : touched) {
                    marks[v] = 0;
                }
                touched.clear();
                return NormalizeResult.tautology(dup);
            }

            int[] lits = new int[touched.size()];

            for (int i = 0; i < touched.size(); i++) {
                int v = touched.get(i);
                lits[i] = marks[v] > 0 ? v : -v;
            }

            Arrays.sort(lits);

            for (int i = 1; i < lits.length; i++) {
                int x = lits[i];
                int j = i - 1;

                while (j >= 0 && Math.abs(lits[j]) > Math.abs(x)) {
                    lits[j + 1] = lits[j];
                    j--;
                }

                lits[j + 1] = x;
            }

            for (int v : touched) {
                marks[v] = 0;
            }
            touched.clear();

            return NormalizeResult.clause(new Clause(id, lits), dup);
        }
    }

    static final class NormalizeResult {
        final Clause clause;
        final boolean emptyClause;
        final boolean tautologicalClause;
        final long duplicateLiterals;
        private NormalizeResult(Clause c, boolean e, boolean t, long d) {
            clause = c; emptyClause = e; tautologicalClause = t; duplicateLiterals = d;
        }
        static NormalizeResult empty() { return new NormalizeResult(null, true, false, 0); }
        static NormalizeResult tautology(long d) { return new NormalizeResult(null, false, true, d); }
        static NormalizeResult clause(Clause c, long d) { return new NormalizeResult(c, false, false, d); }
    }

    static final class Int2 {
        final int a, b;
        Int2(int x, int y) { if (x <= y) { a = x; b = y; } else { a = y; b = x; } }
        @Override public boolean equals(Object o) { return o instanceof Int2 && a == ((Int2)o).a && b == ((Int2)o).b; }
        @Override public int hashCode() { return a * 1_000_003 + b; }
    }

    static final class IntBag {
        int[] data = new int[4];
        int size = 0;
        int add(int value) {
            ensure(size + 1);
            data[size] = value;
            return size++;
        }
        int removeAt(int index) {
            int last = data[--size];
            if (index < size) {
                data[index] = last;
                return last;
            }
            return -1;
        }

        private void ensure(int cap) {
            if (cap > data.length) data = Arrays.copyOf(data, Math.max(cap, data.length * 2));
        }
    }

    static final class IntQueue {
        int[] data = new int[16];
        int head = 0, tail = 0;
        void clear() { head = tail = 0; }
        boolean isEmpty() { return head == tail; }
        void add(int x) {
            ensure(tail + 1);
            data[tail++] = x;
        }
        int poll() { return data[head++]; }
        private void ensure(int cap) {
            if (cap > data.length) data = Arrays.copyOf(data, Math.max(cap, data.length * 2));
        }
    }

    static final class WatchedPropagator {
        final Formula formula;
        final Clause[] clauses;
        final int n;

        final IntBag[] watches;
        final int[] watch0;
        final int[] watch1;
        final int[] assignment;
        final Clause[] reason;
        final int[] trail;
        int trailSize = 0;
        final IntQueue queue = new IntQueue();
        final ArrayList<Clause> unitClauses = new ArrayList<>();

        int conflictVar = 0;
        int conflictNewLit = 0;
        int conflictExistingLit = 0;
        Clause conflictNewReason = null;
        Clause conflictExistingReason = null;

        WatchedPropagator(Formula formula) {
            this.formula = formula;

            this.clauses = formula.clauses;
            this.n = formula.variables;

            this.watches = new IntBag[2 * n + 2];
            for (int i = 0; i < watches.length; i++) watches[i] = new IntBag();
            this.watch0 = new int[clauses.length];
            this.watch1 = new int[clauses.length];
            Arrays.fill(watch0, -1);
            Arrays.fill(watch1, -1);
            this.assignment = new int[n + 1];
            Arrays.fill(assignment, -1);
            this.reason = new Clause[n + 1];
            this.trail = new int[n + 1 + clauses.length * 2];
            initializeWatches();
        }

        private void initializeWatches() {
            for (Clause c : formula.clauses) {
                if (c.lits.length == 0) continue;
                if (c.lits.length == 1) {
                    unitClauses.add(c);
                    continue;
                }
                watch0[c.id] = 0;
                watch1[c.id] = 1;
                watches[litIndex(c.lits[0])].add(c.id);
                watches[litIndex(c.lits[1])].add(c.id);

            }
        }

        void resetAssignments() {
            for (int i = 0; i < trailSize; i++) {
                int v = Math.abs(trail[i]);
                assignment[v] = -1;
                reason[v] = null;
            }
            trailSize = 0;
            queue.clear();
            clearConflictInfo();

        }

        void clearConflictInfo() {
            conflictVar = 0;
            conflictNewLit = 0;
            conflictExistingLit = 0;
            conflictNewReason = null;
            conflictExistingReason = null;
        }

        Clause enqueueRootUnits() {
            for (Clause c : unitClauses) {
                Clause conflict = enqueue(c.lits[0], c);
                if (conflict != null) return conflict;
            }
            return null;
        }

        Clause enqueueDecision(int lit) {
            return enqueue(lit, null);
        }

        Clause enqueue(int lit, Clause why) {
            int v = Math.abs(lit);

            int val = lit > 0 ? 1 : 0;
            int old = assignment[v];
            if (old != -1) {
                if (old == val) return null;

                conflictVar = v;
                conflictNewLit = lit;
                conflictExistingLit = old == 1 ? v : -v;
                conflictNewReason = why;
                conflictExistingReason = reason[v];
                return why != null ? why : reason[v];
            }
            assignment[v] = val;
            reason[v] = why;

            if (trailSize == trail.length) throw new IllegalStateException("Trail overflow");
            trail[trailSize++] = lit;
            queue.add(lit);

            return null;
        }

        Clause propagate() {
            while (!queue.isEmpty()) {

                int trueLit = queue.poll();
                int falseLit = -trueLit;
                IntBag list = watches[litIndex(falseLit)];

                int idx = 0;
                while (idx < list.size) {
                    int cid = list.data[idx];
                    Clause c = clauses[cid];
                    int[] lits = c.lits;

                    int wFalse;
                    int otherWatch;
                    if (watch0[cid] >= 0 && lits[watch0[cid]] == falseLit) {
                        wFalse = 0; otherWatch = watch1[cid];
                    } else if (watch1[cid] >= 0 && lits[watch1[cid]] == falseLit) {
                        wFalse = 1; otherWatch = watch0[cid];
                    } else {

                        idx++;
                        continue;
                    }

                    int otherLit = lits[otherWatch];
                    if (isTrue(otherLit)) {
                        idx++;
                        continue;
                    }

                    int replacement = -1;
                    for (int p = 0; p < lits.length; p++) {
                        if (p == watch0[cid] || p == watch1[cid]) continue;
                        if (!isFalse(lits[p])) {
                            replacement = p;
                            break;
                        }
                    }

                    if (replacement >= 0) {
                        list.removeAt(idx);
                        if (wFalse == 0) watch0[cid] = replacement; else watch1[cid] = replacement;
                        watches[litIndex(lits[replacement])].add(cid);

                        continue;
                    }

                    if (isFalse(otherLit)) {

                        if (lits.length == 2) {
                            int ov = Math.abs(otherLit);
                            conflictVar = ov;
                            conflictNewLit = otherLit;
                            conflictExistingLit = assignment[ov] == 1 ? ov : -ov;
                            conflictNewReason = c;
                            conflictExistingReason = reason[ov];
                        }
                        return c;
                    }

                    Clause conflict = enqueue(otherLit, c);
                    if (conflict != null) return conflict;

                    idx++;
                }
            }
            return null;
        }

        boolean isAssigned(int var) { return assignment[var] != -1; }
        int trueLiteralOf(int var) { return assignment[var] == 1 ? var : -var; }

        boolean isTrue(int lit) {

            int v = Math.abs(lit);
            int a = assignment[v];
            return a != -1 && ((lit > 0 && a == 1) || (lit < 0 && a == 0));
        }

        boolean isFalse(int lit) {

            int v = Math.abs(lit);
            int a = assignment[v];
            return a != -1 && ((lit > 0 && a == 0) || (lit < 0 && a == 1));
        }

        int litIndex(int lit) {
            int v = Math.abs(lit);
            return lit > 0 ? (2 * v) : (2 * v + 1);
        }
    }

    static final class StepResult {
        final int lastIndex;
        final Clause reasonClause;

        StepResult(int lastIndex, Clause reasonClause) {
            this.lastIndex = lastIndex;
            this.reasonClause = reasonClause;

        }
    }

    static final class Candidate {
        final int lit;
        final int var;
        Candidate(int lit) { this.lit = lit; this.var = Math.abs(lit); }
    }

    static final class CSFLOCSolver {
        final Formula formula;
        final BitSet counter = new BitSet();
        final Stats stats;
        final WatchedPropagator propagator;
        final ExactCache exactCache;
        final boolean[] counterValues;
        final Clause[] negativeCause, positiveCause, oldNegativeCause, oldPositiveCause;
        final int[] learnMarks, resolveMarks;
        final ArrayList<Integer> learnTouched = new ArrayList<>();
        final ArrayList<Integer> resolveTouched = new ArrayList<>();
        final long runDeadline;
        boolean finished = false;
        int nextDerivedId = -1;

        CSFLOCSolver(Formula formula, boolean cache, long limitMs) {
            this.formula = formula;
            int n = formula.variables;
            this.exactCache = cache ? new ExactCache(n) : null;
            this.counterValues = new boolean[n + 1];
            this.stats = new Stats(formula, cache);
            this.propagator = new WatchedPropagator(formula);
            this.negativeCause = new Clause[n + 1];
            this.positiveCause = new Clause[n + 1];
            this.oldNegativeCause = new Clause[n + 1];
            this.oldPositiveCause = new Clause[n + 1];
            this.learnMarks = new int[n + 1];
            this.resolveMarks = new int[n + 1];
            this.runDeadline = System.nanoTime() + limitMs * 1000000L;
        }

        void checkRunLimit() {
            if ((stats.mainLoopRuns & 1023) == 0 && System.nanoTime() >= runDeadline) throw new RunLimit();
        }

        StepResult originalExactCandidate() {
            int p = counter.previousSetBit(formula.variables);
            if (p < 1) p = 0;
            Clause c = exactCache.find(counterValues, p);
            return c == null ? null : new StepResult(c.lastVar, c);
        }

        StepResult selectOriginalCandidate(int start) {
            StepResult c = exactCache == null ? null : originalExactCandidate();
            if (c == null) c = findByEffectedCauses(start);
            return c;
        }

        private void addLearnedClause(Clause c) {
            if (c != null && exactCache != null) exactCache.add(c);
        }
        Result solve() {
            long startNs = System.nanoTime();

            if (formula.hasEmptyClause) {
                stats.runtimeNanos = System.nanoTime() - startNs;
                return Result.unsat(stats, "Input contains an empty clause.");
            }
            if (formula.variables == 0) {
                stats.runtimeNanos = System.nanoTime() - startNs;
                return Result.sat(stats, new int[0], new int[0], "Empty formula.");
            }

            while (!finished) {
                checkRunLimit();stats.mainLoopRuns++;
                int startIndex = indexOfLastPositiveLiteral();

                StepResult cached = selectOriginalCandidate(startIndex);

                StepResult step = cached != null ? cached : findByWatchedPropagation();

                if (step == null) {

                    int[] internal = buildInternalModel();
                    int[] original = convertInternalModelToOriginal(internal);
                    stats.runtimeNanos = System.nanoTime() - startNs;
                    return Result.sat(stats, internal, original, null);
                }

                int stepIndex = step.lastIndex;
                if (stepIndex < 1) stepIndex = 1;
                if (stepIndex > formula.variables) stepIndex = formula.variables;

                stepIndex = installCauseAndApplyComplementaryLemma(stepIndex, step.reasonClause);
                if (finished || stepIndex == 0) {
                    break;
                }
                increaseCounter(stepIndex);
            }

            stats.runtimeNanos = System.nanoTime() - startNs;
            return Result.unsat(stats, null);
        }
        int indexOfLastPositiveLiteral() {
            int last = counter.previousSetBit(formula.variables);
            return last >= 1 ? last : 1;
        }
        private StepResult findByEffectedCauses(int startIndex) {
            for (int j = startIndex; j <= formula.variables; j++) {
                boolean bit = counter.get(j);
                StepResult r;
                if (bit) {
                    r = tryCause(positiveCause[j], j); if (r != null) return r;
                    r = tryCause(oldPositiveCause[j], j); if (r != null) return r;
                } else {
                    r = tryCause(negativeCause[j], j); if (r != null) return r;
                    r = tryCause(oldNegativeCause[j], j); if (r != null) return r;
                }
            }
            return null;
        }
        private StepResult tryCause(Clause c, int j) {
            if (c == null || c.lastVar != j) return null;

            if (clauseFitsCounter(c)) {

                return new StepResult(j, c);
            }
            return null;
        }
        private boolean clauseFitsCounter(Clause c) {
            for (int p : c.pos) {

                if (!counter.get(p)) return false;
            }
            for (int v : c.neg) {

                if (counter.get(v)) return false;
            }
            return true;
        }
        private StepResult findByWatchedPropagation() {
            propagator.resetAssignments();
            Candidate best = null;
            int scan = 0;

            Clause conflict = propagator.enqueueRootUnits();
            if (conflict == null) conflict = propagator.propagate();
            best = scanNewCandidates(scan, best);
            scan = propagator.trailSize;
            if (conflict != null) return analyzeConflict(conflict);

            for (int i = 1; i <= formula.variables; i++) {
                if (best != null && best.var <= i) {
                    return analyzeCandidate(best);
                }

                int alphaLit = counter.get(i) ? -i : i;
                if (propagator.isAssigned(i)) {
                    int trueLit = propagator.trueLiteralOf(i);
                    if (trueLit != alphaLit) {

                        return analyzeCandidate(new Candidate(trueLit));
                    }
                    continue;
                }

                conflict = propagator.enqueueDecision(alphaLit);
                if (conflict == null) conflict = propagator.propagate();
                best = scanNewCandidates(scan, best);
                scan = propagator.trailSize;
                if (conflict != null) return analyzeConflict(conflict);
            }

            if (best != null) return analyzeCandidate(best);
            return null;
        }
        private Candidate scanNewCandidates(int from, Candidate best) {
            for (int i = from; i < propagator.trailSize; i++) {
                int lit = propagator.trail[i];
                int var = Math.abs(lit);
                if (propagator.reason[var] == null) continue;
                if (literalMatchesCounter(lit)) {

                    if (best == null || var < best.var) best = new Candidate(lit);
                }
            }
            return best;
        }
        private boolean literalMatchesCounter(int lit) {
            int v = Math.abs(lit);
            return (lit > 0) == counter.get(v);
        }
        private StepResult analyzeCandidate(Candidate cand) {
            Clause reason = propagator.reason[cand.var];
            Clause learned;
            if (reason == null) {
                learned = new Clause(nextDerivedId--, new int[] { cand.lit });
            } else {
                addLearnLiteral(cand.lit);
                for (int lit : reason.lits) {
                    if (lit == cand.lit) continue;
                    explainFalseLiteral(lit);
                }
                learned = buildLearnedClause();
            }
            int idx = learned.lastVar;
            addLearnedClause(learned);

            return new StepResult(idx, learned);
        }
        private StepResult analyzeConflict(Clause conflict) {

            if (propagator.conflictVar > 0
                    && propagator.conflictNewReason != null
                    && propagator.conflictExistingReason != null) {
                return analyzeComplementaryUnitConflict();
            }

            for (int lit : conflict.lits) {
                explainFalseLiteral(lit);
            }
            Clause learned = buildLearnedClause();
            addLearnedClause(learned);
            int idx = learned.lastVar;
            if (idx == 0) {
                finished = true;
                idx = 0;
            }

            return new StepResult(idx, learned);
        }
        private StepResult analyzeComplementaryUnitConflict() {
            int pivot = propagator.conflictVar;
            int newLit = propagator.conflictNewLit;
            int existingLit = propagator.conflictExistingLit;
            Clause newReason = propagator.conflictNewReason;
            Clause oldReason = propagator.conflictExistingReason;

            for (int lit : newReason.lits) {
                if (Math.abs(lit) == pivot && lit == newLit) continue;
                explainFalseLiteral(lit);
            }
            for (int lit : oldReason.lits) {
                if (Math.abs(lit) == pivot && lit == existingLit) continue;
                explainFalseLiteral(lit);
            }

            Clause learned = buildLearnedClause();
            addLearnedClause(learned);
            int idx = learned.lastVar;
            if (idx == 0) {
                finished = true;
                idx = 0;
            }

            return new StepResult(idx, learned);
        }
        private void explainFalseLiteral(int falseLit) {
            int var = Math.abs(falseLit);
            int assigned = propagator.assignment[var];
            if (assigned == -1) {

                addLearnLiteral(falseLit);
                return;
            }
            int trueLit = assigned == 1 ? var : -var;
            Clause r = propagator.reason[var];
            if (r == null) {
                addLearnLiteral(falseLit);
                return;
            }
            for (int lit : r.lits) {
                if (lit == trueLit) continue;
                explainFalseLiteral(lit);
            }
        }
        private void addLearnLiteral(int lit) {
            int v = Math.abs(lit);
            int sign = lit > 0 ? 1 : -1;
            int old = learnMarks[v];
            if (old == 0) {
                learnMarks[v] = sign;
                learnTouched.add(v);
            }
        }
        private Clause buildLearnedClause() {
            int[] lits = new int[learnTouched.size()];
            for (int i = 0; i < learnTouched.size(); i++) {
                int v = learnTouched.get(i);
                lits[i] = learnMarks[v] > 0 ? v : -v;
            }
            for (int v : learnTouched) learnMarks[v] = 0;
            learnTouched.clear();

            for (int i = 1; i < lits.length; i++) {
                int x = lits[i];
                int j = i - 1;
                while (j >= 0 && Math.abs(lits[j]) > Math.abs(x)) {
                    lits[j + 1] = lits[j];
                    j--;
                }
                lits[j + 1] = x;
            }
            return new Clause(nextDerivedId--, lits);
        }
        private int installCauseAndApplyComplementaryLemma(int stepIndex, Clause c) {
            if (c != null && stepIndex > 0 && c.lastVar == stepIndex) {
                installCauseDirect(stepIndex, c);
            }

            int level = (c != null && c.lastVar == stepIndex) ? c.lastVar : stepIndex;
            Clause resolved = applyComplementaryCauseResolution(level);
            if (finished) return 0;
            if (resolved == null) return stepIndex;

            int idx = resolved.lastVar;
            if (idx < 1) idx = 1;

            if (idx > formula.variables) idx = formula.variables;
            return idx;
        }
        private void installCauseDirect(int index, Clause c) {
            if (c == null || index <= 0 || c.lastVar != index) return;
            if (c.lastSignPositive) {
                positiveCause[index] = c;

            } else {
                negativeCause[index] = c;

            }
        }
        private Clause applyComplementaryCauseResolution(int level) {
            Clause lastResolvent = null;
            int i = level;

            while (i >= 1 && i <= formula.variables) {
                Clause n = negativeCause[i];
                Clause p = positiveCause[i];

                if (n == null || p == null) return lastResolvent;

                if (!clausePrefixFitsCounter(n, i) || !clausePrefixFitsCounter(p, i)) {

                    return lastResolvent;
                }

                Clause r = resolveComplementaryCauses(n, p, i);
                if (r == null) {

                    return lastResolvent;
                }

                clearCauses(i);

                if(r.lits.length!=0)addLearnedClause(r);
                if (r.lits.length == 0) {

                    finished = true;
                    return r;
                }

                installCauseDirect(r.lastVar, r);
                lastResolvent = r;

                if (r.lastVar >= i) {

                    return lastResolvent;
                }
                i = r.lastVar;
            }

            return lastResolvent;
        }
        private boolean clausePrefixFitsCounter(Clause c, int pivot) {
            if (c == null || c.lastVar != pivot) return false;
            for (int lit : c.lits) {
                int v = Math.abs(lit);
                if (v == pivot) continue;

                if ((lit > 0) != counter.get(v)) return false;
            }
            return true;
        }
        private Clause resolveComplementaryCauses(Clause neg, Clause pos, int pivot) {
            boolean sawNegPivot = false;
            boolean sawPosPivot = false;

            for (int lit : neg.lits) {
                if (lit == -pivot) { sawNegPivot = true; continue; }
                if (!addResolveLiteral(lit)) {
                    clearResolveMarks();
                    return null;
                }
            }
            for (int lit : pos.lits) {
                if (lit == pivot) { sawPosPivot = true; continue; }
                if (!addResolveLiteral(lit)) {
                    clearResolveMarks();
                    return null;
                }
            }

            if (!sawNegPivot || !sawPosPivot) {
                clearResolveMarks();
                return null;
            }

            int[] lits = new int[resolveTouched.size()];
            for (int k = 0; k < resolveTouched.size(); k++) {
                int v = resolveTouched.get(k);
                lits[k] = resolveMarks[v] > 0 ? v : -v;
            }
            clearResolveMarks();

            for (int a = 1; a < lits.length; a++) {
                int x = lits[a];
                int b = a - 1;
                while (b >= 0 && Math.abs(lits[b]) > Math.abs(x)) {
                    lits[b + 1] = lits[b];
                    b--;
                }
                lits[b + 1] = x;
            }
            return new Clause(nextDerivedId--, lits);
        }
        private boolean addResolveLiteral(int lit) {
            int v = Math.abs(lit);
            int sign = lit > 0 ? 1 : -1;
            int old = resolveMarks[v];
            if (old == 0) {
                resolveMarks[v] = sign;
                resolveTouched.add(v);
                return true;
            }
            return old == sign;
        }
        private void clearResolveMarks() {
            for (int v : resolveTouched) resolveMarks[v] = 0;
            resolveTouched.clear();
        }
        private void clearCauses(int index) {
            if (index <= 0 || index >= negativeCause.length) return;
            if (negativeCause[index] != null) oldNegativeCause[index] = negativeCause[index];
            if (positiveCause[index] != null) oldPositiveCause[index] = positiveCause[index];

            negativeCause[index] = null;
            positiveCause[index] = null;
        }
        private void increaseCounter(int index) {

            for (int k = formula.variables; k > index; k--) {
                if (counter.get(k)) {
                    counter.clear(k);counterValues[k]=false;
                    clearCauses(k);

                }
            }

            int i = index;
            while (i >= 1 && counter.get(i)) {
                counter.clear(i);counterValues[i]=false;
                clearCauses(i);

                i--;
            }
            if (i < 1) {
                finished = true;
                return;
            }
            counter.set(i);counterValues[i]=true;

        }
        private int[] buildInternalModel() {
            int n = formula.variables;
            int[] model = new int[n];
            for (int v = 1; v <= n; v++) {

                model[v - 1] = counter.get(v) ? -v : v;
            }
            return model;
        }
        private int[] convertInternalModelToOriginal(int[] internal) {
            int n = formula.variables;
            boolean[] valueInternal = new boolean[n + 1];
            for (int lit : internal) valueInternal[Math.abs(lit)] = lit > 0;
            int[] original = new int[n];
            for (int originalVar = 1; originalVar <= n; originalVar++) {
                int internalVar = formula.translate[originalVar];
                original[originalVar - 1] = valueInternal[internalVar] ? originalVar : -originalVar;
            }
            return original;
        }
    }

    static final class Result {
        final boolean sat;
        final Stats stats;

        final int[] internalModel;
        final int[] originalModel;
        final String note;

        private Result(boolean sat, Stats stats, int[] internalModel, int[] originalModel, String note) {
            this.sat = sat;
            this.stats = stats;

            this.internalModel = internalModel;
            this.originalModel = originalModel;
            this.note = note;
        }

        static Result sat(Stats stats, int[] internalModel, int[] originalModel, String note) {
            return new Result(true, stats, internalModel, originalModel, note);
        }

        static Result unsat(Stats stats, String note) {
            return new Result(false, stats, null, null, note);
        }

        void print() {
            if (note != null && !note.isEmpty()) System.out.println("c " + note);
            if (sat) {
                System.out.println("s SATISFIABLE");

                printModel(originalModel != null ? originalModel : internalModel);
            } else {
                System.out.println("s UNSATISFIABLE");
            }
            stats.print();
        }

        private void printModel(int[] model) {
            if (model == null) return;
            StringBuilder sb = new StringBuilder("v");
            for (int lit : model) {
                if (sb.length() > 72) {
                    System.out.println(sb);
                    sb.setLength(0);
                    sb.append("v");
                }
                sb.append(' ').append(lit);
            }
            sb.append(" 0");
            System.out.println(sb);
        }
    }

    static final class Stats {
        final Formula formula;
        final boolean cache;
        long mainLoopRuns;
        long runtimeNanos;
        Stats(Formula formula, boolean cache) {
            this.formula = formula;
            this.cache = cache;
        }
        void print() {
            System.out.println("c solver : CSFLOC_2WL4");
            System.out.println("c cache : " + (cache ? "g-old" : "off"));
            System.out.println("c variable renaming strategy : " + formula.renamingStrategy);
            System.out.println("c clustering factor : " + formula.clusteringFactor);
            System.out.println("c variables : " + formula.variables);
            System.out.println("c declared clauses : " + formula.declaredClauses);
            System.out.println("c parsed clauses : " + formula.parsedClauses);
            System.out.println("c kept clauses : " + formula.clauses.length);
            System.out.println("c empty clause present : " + formula.hasEmptyClause);
            System.out.println("c tautological clauses skipped : " + formula.tautologicalClausesSkipped);
            System.out.println("c duplicate literals skipped : " + formula.duplicateLiteralsSkipped);
            System.out.println("c unterminated trailing clauses accepted : " + formula.malformedTrailingClauses);
            System.out.println("c main loop runs : " + mainLoopRuns);
            System.out.printf(java.util.Locale.ROOT, "c runtime seconds : %.6f%n", runtimeNanos / 1_000_000_000.0);
        }
    }

    static final class SimpleResultChecker {
        static boolean checkInternal(Formula f, int[] internalModel) {
            if (internalModel == null) return false;
            boolean[] val = new boolean[f.variables + 1];
            for (int lit : internalModel) val[Math.abs(lit)] = lit > 0;
            for (Clause c : f.clauses) {
                boolean sat = false;
                for (int lit : c.lits) {
                    int v = Math.abs(lit);
                    if (val[v] == (lit > 0)) { sat = true; break; }
                }
                if (!sat) return false;
            }
            return true;
        }
    }
}
