CSFLOC EXPERIMENTS — INFORMATICS 2026, PAPER 238
The One-Watched Literal Data Structure for Ordered Clause Counting
Gábor Kusper and Marcell Herbák
Public no-CNF archive version 1.1 — 26 October 2026

WHAT THIS PACKAGE CONTAINS
The complete 54-instance, four-configuration, two-repetition diagnostic
campaign (432 executions), the original 432-observation comparison campaign,
both watched-literal solvers (1WL1 and 2WL4), and the 21TU reference solver.
Measured Java sources, exact recorded compiled builds, runner scripts,
all selected raw and prepared DIMACS inputs, schedules, commands, stdout,
stderr, timing/memory records, validators, tests and analysis are included.
No newer solver was substituted. In particular, no 2WL5 implementation is used.

All current narrative reports are in English. Raw solver output, original
machine records, source-code snapshots and localized OS error messages are
preserved verbatim. Historical report-writing source snapshots may contain
the former Hungarian report text; they are code provenance, not the current
English reports. The original workspaces and original ZIP were not altered.

MAIN RESULTS
Diagnostic: 108 SAT, 213 UNSAT, 111 TIMEOUT, 0 ERROR; 432/432 observations.
Elapsed campaign time: 2853.5506621000823 seconds (47.56 minutes).
Stable solved instances (both repetitions):
                 original   diagnostic
21TU                  38          38
1WL1 ECD-off          38          38
1WL1 ECD-on           40          41
2WL4                  42          42
All 108 SAT models were rechecked. All 317 executions completed in both
campaigns have identical SAT/UNSAT status and main-loop counts. Java
diagnostics are complete for all 321 successful diagnostic executions.
Peak working-set memory is available for all 432, including timeouts.
No known measurement error requires rerunning the diagnostic campaign.

START READING
reports/RERUN_ASSESSMENT_EN.txt
reports/INSTRUMENTATION_REPORT_EN.txt
reports/ORIGINAL_ARCHIVE_AUDIT_EN.txt
results/diagnostic_native_54_20s_20261025_v1/CAMPAIGN_REPORT_EN.txt
DATA_DICTIONARY.txt
SOURCE_INDEX.txt

KEY DIRECTORIES
sources/       Frozen diagnostic sources, plus explicitly identified
               historical source variants. Do not compile all files together.
tools/         Existing native-renaming benchmark runner and memory helper.
data/          All 54 selected raw.cnf/input.cnf/identity.json sets, manifests
               and the exact 432-job schedule. No downloads are needed to replay.
work/build/    The diagnostic class files actually used in the recorded run.
results/diagnostic_native_54_20s_20261025_v1/
               New raw measurements, environment, validation and analysis.
provenance/original_sources/
               Uninstrumented local source snapshots used as the baseline.
provenance/original_campaign_reference/
               Complete available original primary campaign files, kept apart
               from diagnostic measurements.
historical/    Excluded parser-error attempt, interrupted preflight,
               invalid input, original preparation checks and original builds.
independent_control/
               Separate five-instance, ten-execution second-machine control.
tests/         Test programs and recorded results. All .cnf fixtures are
               omitted; live regression tests need separately restored inputs.
scripts/       Package verification and portable read-only reanalysis.

REQUIREMENTS
Recorded environment: Windows 11 build 26300, Intel Core i7-1255U,
12 logical CPUs, approximately 32 GiB installed RAM, CPython 3.12.14,
OpenJDK 21.0.1+12-29. The benchmark and peak-working-set measurement require
Windows. Python standard library only; no third-party Python packages.
Python and the JDK are prerequisites and are not bundled in this ZIP.
JDK 21.0.1 is required for an exact environment replay.

VERIFY PUBLIC EVIDENCE WITHOUT CNFS OR JAVA
Extract the ZIP and open PowerShell in its top-level folder:
$Python = 'C:\path\to\python.exe'
& $Python 'scripts/verify_public_archive.py'

The public verifier checks package SHA-256 hashes, the frozen 432-run
results, diagnostic fields, and the absence of embedded CNFs. It does NOT
revalidate saved SAT models against absent CNF files and starts no solver.

RESTORE INPUTS BEFORE BENCHMARK REPLAY OR MODEL REVALIDATION
Download the 14 official SATLIB .tar.gz archives listed in
provenance/input_downloads.json into a local folder. See
SATLIB_INPUT_RECONSTRUCTION_EN.txt. Then run:
& $Python 'scripts/restore_satlib_inputs.py' --archives 'C:\path\to\SATLIB_downloads'

After restoring the 54 exact raw/prepared inputs, optional native input
and source auditing can use the existing JDK environment:
$Jdk = 'C:\path\to\jdk-21.0.1'
& $Python 'tools/end_to_end.py' audit --jdk $Jdk

The original private-package scripts/verify_archive.py additionally expects
the removed nested control ZIP and is not the verifier for this release.
The recorded original observations and diagnostics remain available without
restoring any SATLIB input files.

READ-ONLY REANALYSIS INTO A NEW DIRECTORY (INPUTS REQUIRED)
& $Python 'scripts/reanalyze.py' --output 'reanalysis_fresh'
Restore the SATLIB inputs first: this script independently rechecks SAT
models against the reconstructed formulae. The output directory must not
already exist. It does not replace raw data or launch solver benchmarks.

BUILD FROM SOURCE
Use a separate extracted working copy if rebuilding, so recorded artifacts
remain intact. The existing builder writes results/build.json and work/build:
& $Python 'tools/end_to_end.py' build --jdk $Jdk

It compiles precisely 21TU, the prepared ECD-switchable 1WL1 source and 2WL4,
with the shared CounterDiagnostics helper. Original unprepared/ordering
variants and the BigInteger test oracle are not benchmark configurations.

OPTIONAL FUTURE FULL REPLAY — NOT EXECUTED DURING PACKAGING
Only if a new campaign is deliberately desired:
& $Python 'tools/end_to_end.py' run --jdk $Jdk --name 'fresh_replay_001' --max-hours 3
The runner refuses an existing result directory. It uses the frozen schedule
once, CPU 0, fresh JVMs, -Xms64m -Xmx1g, and a 20-second external timeout.
The three-hour option is the overall safety ceiling, not a per-run timeout.
Never retry only slow cases to improve a result. Stop and investigate any
source/build/input audit failure instead of bypassing the guard.

RAW PATHS AND CHECKSUMS
Recorded commands and stdout paths describe the original Windows workspace.
They are historical evidence, not shell commands to execute unchanged on
another machine. The current runner constructs paths relative to this root.
Original primary stdout paths beginning results/native_54_20s_20261001_v2/
resolve in provenance/original_campaign_reference/ in this package.
Other relocated historical evidence is identified in PACKAGE_FILE_MAP.json.

SHA256SUMS at the package root verifies this English package.
Recorded historical checksum manifests remain verbatim under
provenance/recorded_measurement_checksums/. Their original report paths
can differ because English narratives replace the former Hungarian reports.
Raw observations, input bytes, solver sources and class files were not
translated or edited. PACKAGE_PROVENANCE.json documents the distinctions.

See THIRD_PARTY_NOTICES.txt and PRIVACY_AND_PROVENANCE_NOTICE.txt before
any public release. This delivery creates a local ZIP only; it does not
publish, upload, assign a blanket license, or modify the manuscript.
