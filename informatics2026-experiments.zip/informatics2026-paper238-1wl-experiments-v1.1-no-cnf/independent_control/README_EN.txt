INDEPENDENT SECOND-MACHINE CONTROL — SEPARATE DATASET

gabor_recheck_2026-10-02.original.zip is the original unmodified control ZIP.
The adjacent gabor_recheck_2026-10-02/ directory contains its exact files.
ZIP SHA-256:
05a50e38d37c6e8184173e25c365d110bd48951497d22fc0287e157bd583f18d

Scope: five selected instances, two repeats, original 2WL4 only; 10 records,
2 SAT and 8 UNSAT. Inputs, stdout/stderr, host metadata, commands, summary
and crosscheck notes are included. original_control_validation.json is the
separate validation result, not a rewritten runs.jsonl.

This control used a Ryzen 9 5900X/WSL2/OpenJDK 25.0.4.1 machine and CPU 3,
not the primary Windows/JDK21/CPU0 environment. It is not part of either
432-observation primary campaign.

A standalone original control runner, a complete build provenance record
and an explicit external timeout specification were not available in the
control ZIP. Exact recorded commands and source hash are preserved, without
inventing missing settings. The original 2WL4 source snapshot with the
recorded hash is included elsewhere in the package.
