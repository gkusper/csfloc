"""Download official SATLIB archives and freeze the preregistered 334-instance panel.
Does NOT run a SAT benchmark. Network access is needed only on first download.
"""
import hashlib, json, random, re, tarfile, urllib.request
from html.parser import HTMLParser
from urllib.parse import urljoin
from pathlib import Path
import measure as m

BASE='https://www.cs.ubc.ca/~hoos/SATLIB/'
OLD=Path(r'C:\Users\EKKE\Documents\Codex\2026-09-11\hozz-l-tre-a-jelenlegi-csfloc21tu')

class Links(HTMLParser):
    def __init__(self):super().__init__();self.href=None;self.text='';self.links={}
    def handle_starttag(self,tag,attrs):
        if tag=='a':self.href=dict(attrs).get('href');self.text=''
    def handle_data(self,data):
        if self.href:self.text+=data
    def handle_endtag(self,tag):
        if tag=='a' and self.href:self.links[self.text.strip()]=urljoin(BASE,self.href);self.href=None

def file_id(name):
    match=re.match(r'^(u?uf)(\d+)[-_]0*(\d+)\.cnf$',name,re.I)
    return (match[1].lower(),int(match[2]),int(match[3])) if match else None

def remove_final_zero(data):
    """User-authorized benchmark cleanup; never used by the generic DIMACS parser."""
    lines=data.splitlines(keepends=True)
    index=len(lines)-1
    while index>=0 and not lines[index].strip():index-=1
    if index>=0 and lines[index].strip()==b'0':
        del lines[index]
        fixed=b''.join(lines)
        try:
            m.parse_dimacs(fixed.decode('utf-8-sig'))
        except ValueError:
            # A standalone zero can terminate a multi-line clause. Canonical
            # output puts that required zero on the clause line, not a final row.
            return data,False
        return fixed,True
    return data,False

def main():
    jdk=m.jdk_path();m.verify_sources();m.verify_builds()
    archives=m.WORK/'satlib_archives';archives.mkdir(parents=True,exist_ok=True)
    index=archives/'index.html'
    if not index.exists():index.write_bytes(urllib.request.urlopen(BASE+'benchm.html',timeout=30).read())
    parser=Links();parser.feed(index.read_text(errors='replace'))
    buckets=[f'{prefix}{n}-{count}' for n,count in [(50,218),(100,430),(150,645),(200,860),(250,1065)] for prefix in ['uf','uuf']]
    inventory=[];groups={}
    for label in buckets+['SSA','PHOLE','DUBOIS','PRET']:
        url=parser.links[label];archive=archives/Path(url).name
        if not archive.exists():archive.write_bytes(urllib.request.urlopen(url,timeout=60).read())
        members={}
        with tarfile.open(archive,'r:gz') as tf:
            for member in tf:
                if member.isfile() and member.name.lower().endswith('.cnf'):
                    name=Path(member.name).name
                    if name in members:raise ValueError('duplicate archive basename '+name)
                    members[name]=tf.extractfile(member).read()
        groups[label]=members
        inventory.append(dict(label=label,url=url,archive_sha256=m.sha(archive),instances=len(members)))
        print(label,len(members),flush=True)
    # Identify actual recorded experiments, not merely downloaded files.
    excluded=set();origins=[]
    for path in (OLD/'outputs').rglob('*'):
        if path.suffix in ('.json','.csv'):
            text=path.read_text(encoding='utf-8-sig',errors='replace')
            hits=re.findall(r'(?<![A-Za-z0-9])(u?uf)(\d+)[-_]0*(\d+)(?!\d)',text,re.I)
            if hits:origins.append(str(path))
            excluded.update((prefix.lower(),int(n),int(i)) for prefix,n,i in hits)
    rng=random.Random(20260928);selected=[];pilot=[];selection_policy={}
    for label in buckets:
        eligible=sorted((name for name in groups[label] if file_id(name) not in excluded),key=lambda name:file_id(name))
        if len(eligible)<35:
            # Exhaustive prior uf/uuf50/100 correctness suites leave no unseen holdout.
            # Explicitly classify the fixed random sample as a replication benchmark.
            selection_policy[label]=dict(mode='replication_not_holdout',unseen_available=len(eligible),
                reason='Insufficient unseen instances after prior recorded experiments; no outcome-based filtering.')
            eligible=sorted(groups[label],key=lambda name:file_id(name))
        else:selection_policy[label]=dict(mode='exclude_recorded_development',unseen_available=len(eligible))
        chosen=rng.sample(eligible,35)
        for name in chosen[:30]:selected.append((label,name,'UNSAT' if label.startswith('uuf') else 'SAT'))
        for name in chosen[30:]:pilot.append((label,name,'UNSAT' if label.startswith('uuf') else 'SAT'))
    for label,count in [('SSA',8),('PHOLE',5),('DUBOIS',13),('PRET',8)]:
        if len(groups[label])!=count:raise ValueError('unexpected family size '+label)
        for name in sorted(groups[label]):
            expected='SAT' if label=='SSA' and name.startswith('ssa7552') else 'UNSAT'
            selected.append((label,name,expected))
    m.save(m.ROOT/'data/satlib_selection.json',dict(seed=20260928,archives=inventory,
        exclusions=sorted(excluded),exclusion_result_files=origins,selection_policy=selection_policy,
        main=selected,pilot=pilot,
        labels='SATLIB index; SSA individual labels from Benchmarks/SAT/DIMACS/BF/descr.html',
        limitation='uf/uuf50/100 were already exhaustively correctness-tested: replication, not unseen holdout. Other strata exclude identifiable recorded development IDs where possible. Structured families also previously explored.'))
    root=m.ROOT/'data/satlib';root.mkdir(parents=True,exist_ok=True)
    manifests={};excluded_inputs=[]
    for split,selection in [('main',selected),('pilot',pilot)]:
        items=[]
        for label,name,expected in selection:
            original=m.WORK/'satlib_selected'/split/name;original.parent.mkdir(parents=True,exist_ok=True)
            raw=groups[label][name]
            cleaned,changed=remove_final_zero(raw)
            original.write_bytes(cleaned)
            dest=root/split/Path(name).stem
            try:
                m.parse_dimacs(original.read_text(encoding='utf-8-sig'))
            except ValueError as e:
                target=m.ROOT/'data/excluded'/name;target.parent.mkdir(parents=True,exist_ok=True)
                target.write_bytes(original.read_bytes())
                excluded_inputs.append(dict(split=split,family=label,name=name,sha256=m.sha(target),
                    file=m.rel(target),reason=str(e),policy='strict DIMACS validity, no inferred clause boundaries'))
                print('EXCLUDED malformed input',name,str(e),flush=True)
                continue
            item=m.prepare_one(original,dest,'IWCR',jdk,expected,family=label)
            if changed:
                rawpath=m.ROOT/'data/raw_satlib'/name;rawpath.parent.mkdir(parents=True,exist_ok=True);rawpath.write_bytes(raw)
                item.update(raw_source=m.rel(rawpath),raw_source_sha256=m.sha(rawpath),cleanup='removed_final_standalone_zero_user_requested')
            items.append(item)
            if len(items)%30==0:print(split,'prepared',len(items),flush=True)
        m.save(root/(split+'_manifest.json'),items);manifests[split]=items
    # 34 structured + 26 random cases, selected independently of measured outcomes.
    main=manifests['main'];structured=[x for x in main if x['family'] not in buckets]
    randoms=[]
    for label in buckets:randoms.extend(rng.sample([x for x in main if x['family']==label],2))
    remaining=[x for x in main if x['family'] in buckets and x not in randoms]
    randoms.extend(rng.sample(remaining,60-len(structured)-len(randoms)))
    sensitivity=[]
    for item in structured+randoms:
        sensitivity.append(m.prepare_one(m.ROOT/item['original'],root/'sensitivity_NON'/item['id'],'NON',jdk,item['expected'],item['family']))
    m.save(root/'sensitivity_manifest.json',sensitivity)
    m.save(m.ROOT/'data/excluded_inputs.json',excluded_inputs)
    m.save(m.ROOT/'results/benchmark_preparation.json',dict(main=len(main),pilot=len(pilot),sensitivity=len(sensitivity),
        all_expected_labels_present=all(x['expected'] for x in main),benchmark_solving_performed=False,
        excluded_inputs=excluded_inputs,source_index=BASE+'benchm.html'))
    print(f'Prepared main={len(main)}, pilot={len(pilot)}, sensitivity={len(sensitivity)}. No benchmark solving performed.',flush=True)

if __name__=='__main__':main()
