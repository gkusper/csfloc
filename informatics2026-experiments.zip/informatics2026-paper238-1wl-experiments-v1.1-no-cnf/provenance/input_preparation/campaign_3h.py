"""Frozen 54-instance, four-solver, two-repeat campaign with external wall deadlines."""
import argparse, ctypes, datetime, json, math, os, random, re, subprocess, time
from pathlib import Path
import measure as m

NAME='paper_54_20s'
SEED=20260928
LIMIT=20.0
DEADLINE='2026-09-28T19:14:29+00:00'
SOLVERS=['21tu','1wl_off','1wl_on','2wl']

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def pin_one_cpu():
    # Pin this measuring process and its subsequently spawned JVMs, not the machine.
    if os.name!='nt':
        allowed=os.sched_getaffinity(0);cpu=min(allowed);os.sched_setaffinity(0,{cpu});return dict(cpu=cpu,allowed_before=sorted(allowed))
    from ctypes import wintypes
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.GetCurrentProcess.restype=wintypes.HANDLE
    k.GetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.POINTER(ctypes.c_size_t),ctypes.POINTER(ctypes.c_size_t)]
    k.SetProcessAffinityMask.argtypes=[wintypes.HANDLE,ctypes.c_size_t]
    process=k.GetCurrentProcess();allowed=ctypes.c_size_t();system=ctypes.c_size_t()
    if not k.GetProcessAffinityMask(process,ctypes.byref(allowed),ctypes.byref(system)):raise ctypes.WinError(ctypes.get_last_error())
    mask=allowed.value & -allowed.value
    if not k.SetProcessAffinityMask(process,mask):raise ctypes.WinError(ctypes.get_last_error())
    return dict(cpu=mask.bit_length()-1,mask=mask,allowed_before=allowed.value,inherited_by_children=True)

def strategy(item):
    f=item['family']
    if f.startswith(('uf','uuf')):return 'IWCR' if item['n']<=150 else 'CIBR'
    return {'SSA':'CUB','PHOLE':'B','DUBOIS':'CIBR','PRET':'NON'}[f]

def prepare():
    jdk=m.jdk_path();m.build(jdk)
    src=json.loads((m.ROOT/'data/satlib/main_manifest.json').read_text())
    rng=random.Random(SEED);selected=[]
    for n in [50,100,150,200,250]:
        for status in ['SAT','UNSAT']:
            group=sorted([i for i in src if i['family'].startswith(('uf','uuf')) and i['n']==n and i['expected']==status],key=lambda i:i['id'])
            selected.extend(rng.sample(group,3))
    for family,count in [('SSA',8),('PHOLE',5),('DUBOIS',6),('PRET',5)]:
        group=sorted([i for i in src if i['family']==family],key=lambda i:i['id'])
        selected.extend(group if len(group)==count else rng.sample(group,count))
    assert len(selected)==54 and len({i['id'] for i in selected})==54
    dest=m.ROOT/'data'/NAME
    if dest.exists():raise RuntimeError('campaign dataset already exists; do not silently reselect')
    dest.mkdir(parents=True)
    m.save(dest/'selection_before_preprocessing.json',[dict(id=i['id'],family=i['family'],strategy=strategy(i),expected=i['expected'],source_sha256=i['original_sha256']) for i in selected])
    items=[]
    for source in selected:
        item=m.prepare_one(m.ROOT/source['original'],dest/source['id'],strategy(source),jdk,source['expected'],source['family'])
        for key in ['raw_source','raw_source_sha256','cleanup']:
            if key in source:item[key]=source[key]
        # Exact semantic roundtrip of the common permutation, before any solver runs.
        n,cs=m.parse_dimacs((m.ROOT/item['original']).read_text(encoding='utf-8-sig'))
        n2,actual=m.parse_dimacs((m.ROOT/item['input']).read_text())
        perm=json.loads((m.ROOT/item['permutation']).read_text())
        assert n==n2 and sorted(perm)==list(range(n+1))
        expected=[sorted([(1 if l>0 else -1)*perm[abs(l)] for l in c],key=abs) for c in m.normalize(cs)]
        assert actual==expected
        assert item['preprocessor_status'] is None
        items.append(item)
    m.save(dest/'manifest.json',items)
    # Truth-table and real-CLI checks for every new shared strategy, both statuses.
    checks=[]
    fixtures=[('sat',4,[[1,2],[-1,3],[-3,4],[-2,4]]),('unsat',3,[[1],[-1,2],[-2,3],[-3]])]
    for order in ['IWCR','CIBR','B','CUB','NON']:
        for label,n,clauses in fixtures:
            f=m.WORK/'strategy_check.cnf';f.write_text(m.dimacs(n,clauses))
            item=m.prepare_one(f,m.ROOT/'tests'/('family_strategy_'+order+'_'+label),order,jdk,family='strategy_preflight')
            for solver in SOLVERS:
                r=subprocess.run(m.command(jdk,solver,m.ROOT/item['input'],1),capture_output=True,text=True,timeout=5)
                status,validation=m.check_output(r.stdout,item)
                assert r.returncode==0 and status==item['expected'],(order,solver,r.stdout,r.stderr)
                checks.append(dict(strategy=order,solver=solver,expected=item['expected'],status=status))
    m.save(dest/'strategy_preflight.json',dict(passed=len(checks),checks=checks))
    protocol=dict(selection_seed=SEED,instances=54,solvers=SOLVERS,cache=1,repeats=2,per_run_limit_seconds=LIMIT,
        global_deadline_utc=DEADLINE,total_runs=432,max_timeout_sum_seconds=8640,
        ordering='shared deterministic external permutation; solver CLI NON',clustering=5,
        strategies={'random_n<=150':'IWCR','random_n>150':'CIBR','SSA':'CUB','PHOLE':'B','DUBOIS':'CIBR','PRET':'NON'},
        source_article='CSFLOC_with_Watched_Literals_AFL_2026 (15).pdf, Table 1, p.10',
        limitations=['SAT random, n250 and family-wide strategy use are preregistered extensions of article rows',
                     'No alternate-strategy or cache-off campaign in this time budget',
                     'Large UNSAT checked against SATLIB labels, not a CSFLOC proof certificate'])
    m.save(dest/'protocol.json',protocol)
    print('Prepared 54 inputs; 40 strategy/CLI checks PASS.',flush=True)

def run():
    jdk=m.jdk_path();m.verify_sources();m.verify_builds()
    items=json.loads((m.ROOT/'data'/NAME/'manifest.json').read_text())
    deadline=datetime.datetime.fromisoformat(DEADLINE).timestamp()
    remaining=deadline-time.time()
    if remaining<=60:raise RuntimeError('Global budget exhausted before campaign start')
    # Reserve 10 minutes for analysis/saving; never begin a partial four-solver block.
    run_deadline=deadline-600
    monotonic_end=time.perf_counter()+max(0,run_deadline-time.time())
    affinity=pin_one_cpu()
    m.CONFIGS=[dict(id=f'{s}_cache1',solver=s,cache=1) for s in SOLVERS]
    out=m.ROOT/'results'/NAME
    if out.exists():raise RuntimeError('Campaign output already exists')
    out.mkdir(parents=True);(out/'logs').mkdir()
    for item in items:
        for k in ['original','input','permutation']:
            assert m.sha(m.ROOT/item[k])==item[k+'_sha256']
        if 'raw_source' in item:assert m.sha(m.ROOT/item['raw_source'])==item['raw_source_sha256']
    rng=random.Random(SEED);schedule=[]
    # Repeated Latin-square rotations balance each solver's within-block position.
    for repeat in range(2):
        order=list(items);rng.shuffle(order)
        base=list(SOLVERS);rng.shuffle(base)
        for j,item in enumerate(order):
            shift=j%4
            for solver in base[shift:]+base[:shift]:schedule.append((repeat,item,solver))
    m.save(out/'schedule.json',[dict(repeat=r,instance=i['id'],strategy=i['order'],solver=s) for r,i,s in schedule])
    env=m.environment(jdk);env.update(cpu_affinity=affinity,started_utc=now(),global_deadline_utc=DEADLINE,
        measurement_stop_utc=datetime.datetime.fromtimestamp(run_deadline,datetime.timezone.utc).isoformat(),
        protocol=json.loads((m.ROOT/'data'/NAME/'protocol.json').read_text()),
        build=json.loads((m.ROOT/'results/build.json').read_text()),
        source_manifest=json.loads((m.ROOT/'source_manifest.json').read_text()),
        tools={m.rel(p):m.sha(p) for p in (m.ROOT/'tools').glob('*') if p.is_file()},
        manifest_sha256=m.sha(m.ROOT/'data'/NAME/'manifest.json'))
    if os.name=='nt':env['power_scheme']=subprocess.run(['powercfg','/getactivescheme'],capture_output=True,text=True,errors='replace').stdout.strip()
    m.save(out/'environment.json',env);m.save(out/'manifest.json',items)
    rows=[];stop_reason='completed';start=time.perf_counter()
    with (out/'runs.jsonl').open('w',encoding='utf-8') as stream:
        for idx,(repeat,item,solver) in enumerate(schedule):
            # 4*20 seconds plus conservative termination/IO allowance.
            if idx%4==0 and (min(monotonic_end-time.perf_counter(),run_deadline-time.time())<100):
                stop_reason='global_budget';break
            stdout=out/'logs'/f'{idx:04d}.stdout.txt';stderr=out/'logs'/f'{idx:04d}.stderr.txt'
            cmd=m.command(jdk,solver,m.ROOT/item['input'],1)
            started=now();code,wall,timeout=m.timed_process(cmd,stdout,stderr,LIMIT)
            text=stdout.read_text(encoding='utf-8',errors='replace')
            status,validation=m.check_output(text,item)
            if timeout or wall>=LIMIT:status,validation='TIMEOUT','not_validated'
            elif code!=0:status,validation=('OOM' if 'OutOfMemoryError' in stderr.read_text(errors='replace') else 'ERROR'),'process_failed'
            row=dict(run_id=idx,repeat=repeat,instance=item['id'],family=item['family'],strategy=item['order'],
                n=item['n'],m=item['m_normalized'],config=solver+'_cache1',solver=solver,cache=1,
                expected=item['expected'],status=status,validation=validation,wall_seconds=wall,
                exit_code=code,started_utc=started,completed_utc=now(),cpu_seconds=None,peak_memory_bytes=None,
                input_sha256=item['input_sha256'],command=cmd,stdout=m.rel(stdout),stderr=m.rel(stderr))
            rows.append(row);stream.write(json.dumps(row)+'\n');stream.flush()
            progress=dict(completed=len(rows),planned=len(schedule),elapsed_seconds=time.perf_counter()-start,
                statuses={s:sum(r['status']==s for r in rows) for s in sorted({r['status'] for r in rows})},
                last_instance=item['id'],updated_utc=now(),stop_reason=None)
            m.save(out/'progress.json',progress)
            if idx%4==3:print(json.dumps(progress),flush=True)
            if status in ['WRONG','ERROR','OOM']:
                stop_reason='validation_or_process_failure';break
    m.summarize(rows,LIMIT,out)
    # stable_solved in this summary is usable only for full campaigns; otherwise missing repeats explicitly reported.
    completion=dict(completed=len(rows),planned=len(schedule),stop_reason=stop_reason,
                    complete=len(rows)==len(schedule),ended_utc=now(),elapsed_seconds=time.perf_counter()-start,
                    global_deadline_utc=DEADLINE)
    m.save(out/'completion.json',completion);print(json.dumps(completion),flush=True)
    if stop_reason=='validation_or_process_failure':raise SystemExit(2)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['prepare','run']);a=p.parse_args()
    prepare() if a.action=='prepare' else run()
