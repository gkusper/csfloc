import pathlib,shutil,json,hashlib,sys
old=pathlib.Path('outputs/CSFLOC_measurement');root=pathlib.Path('outputs/CSFLOC_end_to_end')
assert not (root/'protocol.json').exists()
root.mkdir(exist_ok=True);shutil.copytree(old/'sources',root/'sources',dirs_exist_ok=True);(root/'tools').mkdir(exist_ok=True)
for name in ['measure.py','BatchDriver.java','SharedOrder.java']:shutil.copy2(old/'tools'/name,root/'tools'/name)
shutil.copy2(old/'source_manifest.json',root/'source_manifest.json')
sys.path.insert(0,str(old/'tools'));import measure as m
items=[]
for x in json.loads((old/'data/paper_54_20s/manifest.json').read_text()):
 raw=(old/x.get('raw_source',x['original'])).read_bytes();lines=raw.splitlines(keepends=True);j=len(lines)-1
 while j>=0 and not lines[j].strip():j-=1
 removed=j>=0 and lines[j].strip()==b'0'
 if removed:del lines[j]
 cleaned=b''.join(lines)
 try:n,cs=m.parse_dimacs(cleaned.decode('utf-8-sig'))
 except ValueError:
  cleaned=raw;removed=False;n,cs=m.parse_dimacs(cleaned.decode('utf-8-sig'))
 assert cleaned==(old/x['original']).read_bytes()
 # Legacy readers consume one clause per physical line; check exact clause sequence.
 actual=[]
 for line in cleaned.decode().splitlines():
  if not line or line[0] in 'pc%0':continue
  toks=list(map(int,line.split()));actual.append(toks[:-1] if toks[-1]==0 else toks)
 reflow=actual!=cs or next(l.strip() for l in reversed(cleaned.splitlines()) if l.strip())==b'0'
 if reflow:cleaned=m.dimacs(n,cs).encode('ascii')
 assert m.parse_dimacs(cleaned.decode())==(n,cs)
 assert next(l.strip() for l in reversed(cleaned.splitlines()) if l.strip())!=b'0'
 folder=root/'data'/x['id'];folder.mkdir(parents=True,exist_ok=True)
 (folder/'input.cnf').write_bytes(cleaned);(folder/'raw.cnf').write_bytes(raw)
 (folder/'identity.json').write_text(json.dumps(list(range(n+1))))
 item=dict(x);item.update(input=f'data/{x["id"]}/input.cnf',original=f'data/{x["id"]}/input.cnf',permutation=f'data/{x["id"]}/identity.json',raw_source=f'data/{x["id"]}/raw.cnf',cleanup=('clause_line_reflow_without_reordering' if reflow else 'removed_final_standalone_zero' if removed else 'unchanged'),external_permutation=False)
 for k in ['input','original','permutation','raw_source']:item[k+'_sha256']=m.sha(root/item[k])
 items.append(item)
(root/'data/manifest.json').write_text(json.dumps(items,indent=2))
shutil.copy2(old/'results/paper_54_20s/schedule.json',root/'data/schedule.json')
protocol=dict(instances=54,repeats=2,solvers=['21tu','1wl_off','1wl_on','2wl'],cache=1,limit_seconds=20,max_hours=3,clustering=5,
 measurement='external wall time: fresh JVM startup + original CNF reading + solver-native renaming + solving + output',
 excluded='byte-preserving removal of extraneous final standalone zero; independent model validation; compilation',
 input_order='Original SATLIB variable, clause and literal order; no offline renaming or normalization',
 strategies={'random <=150':'IWCR','random >150':'CIBR','SSA':'CUB','PHOLE':'B','DUBOIS':'CIBR','PRET':'NON'},
 caveats=['Native renaming implementations may have different tie-breaking; identical strategies do not certify identical internal permutations.','The old offline permutation measurements remain separate; no new performance results yet.'],status='PREPARED_NOT_RUN')
(root/'protocol.json').write_text(json.dumps(protocol,indent=2))
print('Prepared',len(items),'byte-preserving cleaned original inputs; physical-line parser audit PASS')


