import zipfile,json,re,hashlib
from pathlib import Path
z=zipfile.ZipFile(r'C:\Users\EKKE\Downloads\gabor_recheck_2026-10-02.zip'); prefix='gabor_recheck_2026-10-02/'
r=[json.loads(x) for x in z.read(prefix+'runs.jsonl').decode().splitlines() if x.strip()]
print('ROW',json.dumps(r[0]));print('rows',len(r))
R=Path('outputs/CSFLOC_end_to_end');local=[json.loads(x) for x in (R/'results/native_54_20s_20261001_v2/runs.jsonl').read_text().splitlines()]
def parse(b):
 clauses=[];cur=[];header=None
 for line in b.decode('utf-8-sig').splitlines():
  line=line.strip()
  if not line or line.startswith(('c','%')):continue
  if line.startswith('p'):header=line.split()[2:];continue
  for x in map(int,line.split()):
   if x==0:clauses.append(cur);cur=[]
   else:cur.append(x)
 assert not cur
 return header,clauses
out=[]
for iid in ['pret60_25','hole6','hole7','ssa0432-003','ssa7552-160']:
 mb=z.read(prefix+'inputs/'+iid+'.cnf');lb=(R/'data'/iid/'input.cnf').read_bytes();ms=[];ls=[]
 for n in z.namelist():
  if '/logs/'+iid+'-' in n and n.endswith('.out'):
   t=z.read(n).decode();ms.append(int(re.search(r'main loop runs\s*:\s*(\d+)',t)[1]));assert ('s SATISFIABLE' if iid=='ssa7552-160' else 's UNSATISFIABLE') in t
   if iid=='ssa7552-160':
    model={abs(int(x)):int(x)>0 for line in t.splitlines() if line.startswith('v ') for x in line.split()[1:] if int(x)!=0};assert all(any(model.get(abs(x))==(x>0) for x in c) for c in parse(mb)[1])
 for q in local:
  if q['solver']=='2wl' and q['instance']==iid:ls.append(int(re.search(r'main loop runs\s*:\s*(\d+)',(R/q['stdout']).read_text())[1]))
 result=dict(instance=iid,ordered_formula_equal=parse(mb)==parse(lb),byte_equal=mb==lb,local_loops=ls,marcell_loops=ms,loops_equal=ls==ms)
 assert result['ordered_formula_equal'] and result['loops_equal'];out.append(result);print(result)
Path('outputs/measurement_consistency/marcell_recheck_verified.json').write_text(json.dumps(dict(zip_sha256=hashlib.sha256(Path(r'C:\Users\EKKE\Downloads\gabor_recheck_2026-10-02.zip').read_bytes()).hexdigest(),rows=len(r),cases=out,sat_models_checked=2),indent=2))
