"""Write the Hungarian report and hash new artifacts; no solver execution."""
from pathlib import Path
import json,hashlib,shutil,datetime
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/diagnostic_native_54_20s_20261025_v1';A=OUT/'analysis'
S=json.loads((A/'summary.json').read_text(encoding='utf-8'))
P=json.loads((A/'per_instance_diagnostics.json').read_text(encoding='utf-8'))
idx={(p['instance'],p['solver']):p for p in P}
solvers=['21tu','1wl_off','1wl_on','2wl']
def both(iid):return all(idx.get((iid,s),{}).get('both_repetitions_successful',False) for s in solvers)
short=[]
for iid in ['uuf150-027','ssa6288-047']:
 successful=[s for s in solvers if idx.get((iid,s),{}).get('both_repetitions_successful',False)]
 if len(successful)>=2:short.append((iid,'ECD-kontraszt; timeoutos módoknál a Java-számlálók nem összehasonlíthatók.'))
for choices,reason in [
 (['uf150-046','uuf100-0371','uf100-010','uf50-0806'],'Közösen, mindkét ismétlésben megoldott véletlen példa.'),
 (['uf100-010','uf50-0806'],'Közösen megoldott SAT véletlen példa, az UNSAT véletlen példa mellé.'),
 (['ssa0432-003','ssa7552-160'],'Mind a négy móddal megoldott SSA kontroll.'),
 (['hole7','hole6'],'Mind a négy móddal megoldott PHOLE példa.'),
 (['dubois20','dubois21','dubois22'],'Mind a négy móddal megoldott DUBOIS példa.')]:
 hit=next((i for i in choices if both(i)),None)
 if hit:short.append((hit,reason))
shortdata=[]
for iid,reason in short:
 shortdata.append({'instance':iid,'selection_reason':reason,'configurations':[idx[(iid,s)] for s in solvers]})
(A/'diagnostic_table_shortlist.json').write_text(json.dumps(shortdata,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
lines=[]
def add(s=''):lines.append(s)
add('CSFLOC – TELJES DIAGNOSZTIKAI KAMPÁNY')
add('Informatics 2026, Paper ID 238')
add('Jelentés a fagyasztott 432-es sorozatról; kis regressziós tesztekből származó teljesítményadatot nem használ.')
add()
add('1. Mérési könyvtár')
add(str(OUT))
add('A meglévő, változatlan tools/end_to_end.py run parancs futott le egyszer, --max-hours 3 teljes sorozatvédő plafonnal. Ez nem változtatja a futásonkénti 20 másodperces határt.')
add('Kezdet: '+json.loads((OUT/'environment.json').read_text())['started_utc'])
add('Befejezés: '+S['completion']['ended_utc'])
add('Kampányidő: %.2f perc.'%(S['completion']['elapsed_seconds']/60))
add()
add('2. Eredeti környezet és ütemezés')
add('Az eredeti data/schedule.json bájtra változatlan; SHA-256: e8f7437745209e30ba6f702e4ba3286c1bb34f04278ef99e5560e8425a9304bc. Az 54 input és mind a 432 parancsbeállítás indulás előtt ellenőrzött; a végső sorrend és a (példány, solver, ismétlés) kulcsok ellenőrzése az analysis/summary.json fájlban van.')
add('Az eredeti gépazonosító, Intel Core i7-1255U, 12 logikai CPU, Windows 11 build 26300, Python 3.12.14 és OpenJDK 21.0.1 egyezik. CPU 0, örökölt affinitás, friss JVM, -Xms64m -Xmx1g, clustering=5, az eredeti cache/stratégia, primitive trail=1, unitChainMode=0. Az ECD-off/on ugyanazt az 1WL-buildet használja.')
add('Az OS 34 010 619 904 bájt használható fizikai memóriát jelentett, ami összhangban van az eredeti 32 GiB telepített RAM-mal. A pontos telepített-RAM API és a CIM hozzáférést megtagadott; ezt az előkészítési jegyzőkönyv rögzíti. Lényegi gépkörnyezet-váltást nem találtam.')
add()
add('3. Darabszámok')
add('Megfigyelések: %d/432; különböző példányok: %d.'%(S['observations'],S['distinct_instances']))
add('SAT: %d; UNSAT: %d; TIMEOUT: %d; ERROR/egyéb: %d.'%(S['statuses'].get('SAT',0),S['statuses'].get('UNSAT',0),S['statuses'].get('TIMEOUT',0),sum(v for k,v in S['statuses'].items() if k not in ['SAT','UNSAT','TIMEOUT'])))
add('Eredeti sorozat: 106 SAT, 211 UNSAT, 115 TIMEOUT. Minden sikertelen próbálkozás is megőrzött; újrafuttatás nem történt.')
add()
add('4. Mindkét ismétlésben megoldott példányok: eredeti → diagnosztikai')
for s in solvers:
 x=S['summary_by_configuration'][s]
 add('%-8s %2d → %2d; új státuszok: %s.'%(s,x['original_stable_solved'],x['diagnostic_stable_solved'],x['diagnostic_statuses']))
add()
add('5. Válaszok és főciklusszámok')
add('Újraellenőrzött SAT-modellek: %d; UNSAT-referenciacímke-egyezések: %d.'%(S['SAT_models_rechecked'],S['UNSAT_reference_agreements']))
add('Az UNSAT-bizonyítványokat nem ellenőriztük függetlenül; a referenciacímkét és a rendelkezésre álló eredeti eredményt ellenőriztük.')
add('Régi és új sorozatban egyaránt sikeres megfigyelések: %d; eltérő főciklusszámok: %d.'%(S['old_new_common_completed_observations'],len(S['old_new_main_loop_differences'])))
add('Minden régi/új státuszváltás és ciklusszám-összehasonlítás: analysis/original_diagnostic_comparison.json. Megváltozott státuszok száma: %d.'%len(S['status_changes']))
add('SAT/UNSAT ellentmondás: %d.'%sum(p['kind']=='SAT_UNSAT_contradiction' for p in S['problems']))
add()
add('6. Az új diagnosztika teljessége')
add('Sikeres futás, mindhárom Java-mennyiséggel (főciklus + két új számláló): %d/%d.'%(S['diagnostic_counters_complete_successful_observations'],S['statuses'].get('SAT',0)+S['statuses'].get('UNSAT',0)))
add('Pozitív, bájtban mért csúcs munkakészlet: %d/%d futás, a timeoutokat is beleértve.'%(S['memory_present_all_statuses'],S['observations']))
add('A számlálókat nem helyettesítettük hiány esetén nullával. A timeoutos Java-számlálók null értékűek; memóriaértékük külön megőrzött.')
add('A főciklusszámot a változatlan solverstdoutból emeltük át a külön runs_diagnostics.jsonl fájlba. A nyers runs.jsonl nem változott. Az összes korábbi kiírt statisztika megvan a stdoutban és a származtatott rekord solver_statistics objektumában.')
add()
add('7. Hiányzó mezők és memóriahibák')
add('Memóriamérési hibák száma: %d. Problémák: %d. Figyelmeztetések: %d.'%(len(S['memory_errors']),len(S['problems']),len(S['warnings'])))
for p in S['memory_errors']:add(str(p))
for p in S['problems']:add(str(p))
for p in S['warnings']:add(str(p))
add('A mérési módszer Windows GetProcessMemoryInfo / PeakWorkingSetSize; nem heapméret, és nem -Xmx. A módszer és a hibaok helye environment.json / peak_working_set_error.')
add()
add('8. Futásidő- és timeouteltérések')
old_to_new=__import__('collections').Counter((r['original_status'],r['diagnostic_status']) for r in S['status_changes'])
for (old,new),n in sorted(old_to_new.items()):add('%s → %s: %d megfigyelés.'%(old,new,n))
newrows=[json.loads(l) for l in (OUT/'runs.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
add('Az összes státuszeltérés, a mostani diagnosztikai futás idejével:')
for change in S['status_changes']:
 row=next(r for r in newrows if all(r[k]==change[k] for k in ['instance','solver','repeat']))
 add('- %s, %s, %d. ismétlés: %s → %s; új idő %.6f s; főciklus %s.'%(change['instance'],change['solver'],change['repeat']+1,change['original_status'],change['diagnostic_status'],row['wall_seconds'],change['diagnostic_main_loop_iterations']))
add('A runtime-átlagokat kizárólag az új diagnosztikai sorozat két sikeres ismétléséből számoltuk. A timeoutok és a hiányzó adatok nem 0-ként szerepelnek. Régi és új nyers futásidőket nem vontunk össze közös teljesítménystatisztikába.')
add('A timeoutstátuszok változása összeegyeztethető a műszerezés többletmunkájával és a futásidő változékonyságával; ebből nem állítható kizárólagos okozati magyarázat. A különböző solverek inference-, learning- és belső rendezési eltérései miatt a diagnosztikai összehasonlítás leíró jellegű; nem a watch-szám önálló hatásának mérése.')
add()
add('9. Javasolt rövid diagnosztikai táblázat példányai')
for iid,reason in short:add('- '+iid+': '+reason)
for iid in ['uuf150-027','ssa6288-047']:
 if not any(x[0]==iid for x in short):
  add(iid+' külön megvizsgálva, de nem került a javasolt listába: nincs legalább két, mindkét ismétlésben sikeres konfiguráció; a konkrét adatok a per-instance fájlban megvannak.')
add('uuf150-027: a 21TU és az ECD-off 1/2, az ECD-on és a 2WL4 2/2 ismétlést oldott meg. Ezért az első két módhoz nincs két sikeres körből számított átlag; a sikeres egyedi rekord megmaradt.')
add('ssa6288-047: 21TU és ECD-off 0/2, ECD-on és 2WL4 2/2. A 2WL4 itt 1 főciklust, 256 bemenetiklóz-vizsgálatot és 0 nemtriviális ugrást rögzít mindkét körben; a nulla tényleges eseményszám, nem hiányzó adat pótlása.')
add('A kiválasztott példányok mindkét ismétlése, metrikái és csak sikeres párokból képzett átlagai: analysis/diagnostic_table_shortlist.json. Ez előkészítési javaslat; LaTeX-et vagy kéziratot nem módosítottam.')
add()
add('10. Pontos eredményfájlok és integritás')
for f in ['runs.jsonl','runs.csv','logs/','environment.json','manifest.json','schedule.json','completion.json','preflight.json','analysis/runs_diagnostics.jsonl','analysis/per_instance_diagnostics.json','analysis/summary.json','analysis/validation_records.json','analysis/original_diagnostic_comparison.json','analysis/diagnostic_table_shortlist.json','SHA256SUMS']:
 add(str(OUT/f))
add('Új nyers runs.jsonl SHA-256: '+hashlib.sha256((OUT/'runs.jsonl').read_bytes()).hexdigest())
add('Eredeti nyers runs.jsonl SHA-256: 5ec2461870d7fbf303ad4e0a282a36cb4a95abb1eda345fd05acc9aad9bbca29. A két mérés eredete elkülönített.')
add('Az új műtermékek ellenőrző összegei a SHA256SUMS fájlban vannak. Az eredeti archívum és a hivatkozott 432 eredeti megfigyelés SHA-256-ja változatlan. A diagnosztikai források, buildek és bemeneti manifest/ütemezés a kampány végén is egyeztek az indulási hash-ekkel. A korábbi magyar dokumentáció nem változott.')
add('A futtató és a solverek kódja változatlan maradt; nem készült új publikációs ZIP, feltöltés vagy kézirat-módosítás.')
add()
ok=S['complete']
add('DIAGNOSTIC CAMPAIGN COMPLETE: '+('YES' if ok else 'NO'))
if ok:add('A teljes mérések és az ellenőrzések alapján az adatok elég teljesek és következetesek a camera-ready diagnosztikai táblázat elkészítéséhez. A timeoutos összehasonlításokhoz hiányzó Java-számlálókat továbbra is hiányként kell jelölni.')
else:add('Fennmaradó akadályok: '+json.dumps(S['problems'],ensure_ascii=False))
(OUT/'JELENTES_HU.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
shutil.copy2(ROOT/'work/analyze_full_campaign.py',A/'analyze_full_campaign.py')
shutil.copy2(Path(__file__),A/'write_campaign_report.py')
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.name!='SHA256SUMS')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(OUT).as_posix()+'\n' for p in files)
(OUT/'SHA256SUMS').write_text(manifest,encoding='utf-8')
for line in manifest.splitlines():
 digest,name=line.split('  ',1);assert hashlib.sha256((OUT/name).read_bytes()).hexdigest()==digest
print('Report:',OUT/'JELENTES_HU.txt')
print('Checksums verified:',len(files))
print('Shortlist:',[v[0] for v in short])
print('DIAGNOSTIC CAMPAIGN COMPLETE: '+('YES' if ok else 'NO'))
