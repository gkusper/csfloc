HISTORICAL AND EXCLUDED MATERIAL — NOT DIAGNOSTIC CAMPAIGN DATA

excluded_header_whitespace_attempt/: five observations from the abandoned
October 1 native attempt (four SAT, one parser ERROR), its logs and all 54
pre-fix input copies. The corrected original v2 campaign restarted fully.
These records do not belong to either 432-observation main dataset.

interrupted_preflight_checks/: the separate original small test series
interrupted by Windows standby. original_preflight_checks/ and
original_preflight_fixtures/ retain the successful 160-check replacement
and its fixtures. These are correctness tests, not performance observations.

excluded_invalid_input/dubois100.cnf: rejected before selecting the frozen
54 cases because of a strict DIMACS clause-count mismatch.

original_preparation/: original build/header-fix/reader-audit records and
controller metadata. The same original build hashes are also retained with
original_recorded_builds/; the associated class files were checked before
copying. Original code/controller snapshots can contain expired absolute
dates and local paths. They are historical evidence, not current replay
entrypoints. Use the root README and the existing native runner.

Do not combine any excluded/test record with the 432 original primary or
432 diagnostic observations. Recorded stdout paths retain original prefixes;
use this directory and provenance/PACKAGE_FILE_MAP.json to locate the copies.
